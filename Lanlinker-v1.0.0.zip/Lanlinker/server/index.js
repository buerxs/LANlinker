'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');

const store = require('./store');
const signaling = require('./signaling');
const { handleApi, setShutdownHook } = require('./api');
const { serveStatic } = require('./static');
const { localIPv4s, isRegisterOpen } = require('./util');

const PORT = Number(process.env.PORT || 5178);
const HOST = process.env.HOST || '0.0.0.0';
const USE_HTTPS = String(process.env.HTTPS || '') === '1';
// 公网部署时显式指定对外可访问的域名/地址（含协议），例如 https://lanlinker.example.com
const PUBLIC_URL = String(process.env.LANLINKER_PUBLIC_URL || '').trim();

store.load();

function createServer() {
  const handler = (req, res) => {
    // 供页面显示「手机该访问哪个地址」，避免局域网 IP 变了以后找不到服务
    if (req.url === '/api/lan-info') return sendLanInfo(req, res);
    if (req.url.startsWith('/api/')) return handleApi(req, res);
    if (req.url === '/healthz') {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ ok: true, ...signaling.stats() }));
    }
    return serveStatic(req, res);
  };

  if (USE_HTTPS) {
    const certDir = path.join(__dirname, '..', 'certs');
    const key = path.join(certDir, 'key.pem');
    const cert = path.join(certDir, 'cert.pem');
    if (fs.existsSync(key) && fs.existsSync(cert)) {
      // eslint-disable-next-line global-require
      const https = require('https');
      return https.createServer({ key: fs.readFileSync(key), cert: fs.readFileSync(cert) }, handler);
    }
    console.warn('[server] 未找到 certs/key.pem 与 certs/cert.pem，回退到 HTTP');
  }
  return http.createServer(handler);
}

const server = createServer();
signaling.attach(server);

/**
 * 当前服务的访问地址列表。
 * - 默认返回本机所有内网 IP（局域网扫码用）。
 * - 公网部署时（设置 LANLINKER_PUBLIC_URL，或经反向代理带 X-Forwarded-Proto / Host 头），
 *   把可对外访问的域名放到首位并作为二维码地址，避免扫出不可用的内网 IP。
 */
function sendLanInfo(req, res) {
  const port = req.socket.localPort || PORT;
  const scheme = forwardedScheme(req);
  const urls = localIPv4s().map((nic) => ({
    address: nic.address,
    name: nic.name,
    url: `${scheme}://${nic.address}:${port}`,
  }));

  let primary = urls.length ? urls[0].url : null;
  if (PUBLIC_URL) {
    urls.unshift({ address: '(public)', name: '公网域名', url: PUBLIC_URL });
    primary = PUBLIC_URL;
  } else if (req.headers.host) {
    // 经 Nginx / Cloudflare 反代时，Host 头即对外域名
    const publicUrl = `${scheme}://${req.headers.host}`;
    urls.unshift({ address: req.headers.host.split(':')[0], name: '公网域名', url: publicUrl });
    primary = publicUrl;
  }

  res.writeHead(200, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify({ port, scheme, urls, primary, registerOpen: isRegisterOpen() }));
}

/** 推断对外访问协议：优先信任反向代理的 X-Forwarded-Proto，其次看自身是否 HTTPS */
function forwardedScheme(req) {
  const fwd = String(req.headers['x-forwarded-proto'] || '').split(',')[0].trim();
  if (fwd === 'https' || fwd === 'http') return fwd;
  return typeof server.setSecureContext === 'function' ? 'https' : 'http';
}

server.listen(PORT, HOST, () => {
  const scheme = USE_HTTPS && server.constructor.name === 'Server' && server.setSecureContext ? 'https' : 'http';
  const lines = [];
  lines.push('');
  lines.push('  Lanlinker服务已启动');
  lines.push('  ────────────────────────────────');
  lines.push(`  本机访问：    ${scheme}://localhost:${PORT}`);
  if (PUBLIC_URL) {
    lines.push(`  公网访问：    ${PUBLIC_URL}`);
  }
  for (const nic of localIPv4s()) {
    lines.push(`  局域网访问：  ${scheme}://${nic.address}:${PORT}   (${nic.name})`);
  }
  lines.push('  ────────────────────────────────');
  lines.push(PUBLIC_URL ? '  手机 / 其它设备用上面的「公网访问」地址打开即可' : '  手机 / 其它电脑连同一个 WiFi，用上面的「局域网访问」地址打开即可');
  lines.push('  同一账号登录的设备会自动互相出现在设备列表中');
  lines.push(`  开放注册：    ${isRegisterOpen() ? '是' : '否（仅已存在账号可登录）'}`);
  lines.push('');
  console.log(lines.join('\n'));
});

server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.error(`[server] 端口 ${PORT} 已被占用，可用 PORT=5179 node server/index.js 换一个端口`);
  } else {
    console.error('[server]', err);
  }
  process.exit(1);
});

let shuttingDown = false;

/** 优雅关闭：断开所有实时连接 → 落盘 → 退出 */
function shutdown(reason) {
  if (shuttingDown) return;
  shuttingDown = true;
  console.log(`\n正在关闭服务${reason ? `（${reason}）` : ''}…`);
  try {
    signaling.closeAll();
  } catch (err) {
    console.error('[server] 关闭连接时出错：', err.message);
  }
  try {
    store.saveNow();
  } catch (err) {
    console.error('[server] 保存数据失败：', err);
  }
  if (typeof server.closeAllConnections === 'function') server.closeAllConnections();
  if (typeof server.closeIdleConnections === 'function') server.closeIdleConnections();
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 1500).unref();
}

setShutdownHook(() => shutdown('本机停止命令'));

for (const sig of ['SIGINT', 'SIGTERM']) {
  process.on(sig, () => shutdown(sig));
}
