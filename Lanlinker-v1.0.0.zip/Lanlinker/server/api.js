'use strict';

const store = require('./store');
const signaling = require('./signaling');
const { sendJson, readJsonBody, cleanText, lanIdFromIp, normalizeIp, isRegisterOpen } = require('./util');

const USERNAME_RE = /^[A-Za-z0-9_.\-\u4e00-\u9fa5]{2,24}$/;

/**
 * 简单限流：按「IP + 键」在滑动窗口内累计失败次数，超限返回 429。
 * 只挡爆破，不追求精确；内存占用有上限，重启即清零。
 */
const RATE_WINDOW = 10 * 60 * 1000;
const RATE_MAX = 15;
const rateBuckets = new Map(); // key -> { count, start }

function rateLimit(key) {
  const now = Date.now();
  if (rateBuckets.size > 5000) {
    for (const [k, v] of rateBuckets) {
      if (now - v.start > RATE_WINDOW) rateBuckets.delete(k);
    }
  }
  const bucket = rateBuckets.get(key);
  if (!bucket || now - bucket.start > RATE_WINDOW) {
    rateBuckets.set(key, { count: 1, start: now });
    return true;
  }
  bucket.count += 1;
  return bucket.count <= RATE_MAX;
}

function clearRateLimit(key) {
  rateBuckets.delete(key);
}

function getToken(req) {
  const auth = req.headers['authorization'] || '';
  if (auth.toLowerCase().startsWith('bearer ')) return auth.slice(7).trim();
  return '';
}

function requireUser(req) {
  const token = getToken(req);
  const user = store.getUserByToken(token);
  if (!user) throw Object.assign(new Error('登录状态已失效，请重新登录'), { status: 401, code: 'unauthorized' });
  return { user, token };
}

function clientIp(req) {
  return normalizeIp(req.socket.remoteAddress);
}

/**
 * 优雅关闭钩子，由 server/index.js 注入。
 * 供 stop.bat / stop.sh 调用：先落盘再退出，避免强杀丢失数据。
 * 仅接受来自本机的请求。
 */
let shutdownHook = null;
function setShutdownHook(fn) {
  shutdownHook = fn;
}

function isLoopback(req) {
  const ip = String(req.socket?.remoteAddress || '');
  return ip === '127.0.0.1' || ip === '::1' || ip === '::ffff:127.0.0.1';
}

async function handleApi(req, res) {
  const url = new URL(req.url, 'http://localhost');
  const route = `${req.method} ${url.pathname}`;

  try {
    switch (route) {
      case 'POST /api/register': {
        if (!isRegisterOpen()) {
          throw Object.assign(new Error('当前服务已关闭开放注册，请使用已有账号登录，或联系管理员开通'), { status: 403, code: 'register_closed' });
        }
        if (!rateLimit(`register:${clientIp(req)}`)) {
          throw Object.assign(new Error('注册过于频繁，请 10 分钟后再试'), { status: 429, code: 'rate_limited' });
        }
        const body = await readJsonBody(req);
        const username = cleanText(body.username, 24);
        const password = String(body.password || '');
        if (!USERNAME_RE.test(username)) {
          throw Object.assign(new Error('账号需为 2-24 位中文、字母、数字或 _ . -'), { status: 400 });
        }
        if (password.length < 6 || password.length > 128) {
          throw Object.assign(new Error('密码长度需为 6-128 位'), { status: 400 });
        }
        const user = store.createUser(username, password);
        const token = store.createSession(user.id);
        return sendJson(res, 200, { token, user: store.publicUser(user) });
      }

      case 'POST /api/login': {
        const body = await readJsonBody(req);
        const username = cleanText(body.username, 24);
        const password = String(body.password || '');
        const limitKey = `login:${clientIp(req)}:${username}`;
        if (!rateLimit(limitKey)) {
          throw Object.assign(new Error('尝试次数过多，请 10 分钟后再试'), { status: 429, code: 'rate_limited' });
        }
        const user = store.findUserByName(username);
        if (!user || !store.verifyPassword(user, password)) {
          throw Object.assign(new Error('账号或密码不正确'), { status: 401, code: 'bad_credentials' });
        }
        clearRateLimit(limitKey);
        const token = store.createSession(user.id);
        return sendJson(res, 200, { token, user: store.publicUser(user) });
      }

      case 'POST /api/logout': {
        const { token } = requireUser(req);
        store.deleteSession(token);
        return sendJson(res, 200, { ok: true });
      }

      case 'GET /api/session': {
        const { user } = requireUser(req);
        return sendJson(res, 200, {
          user: store.publicUser(user),
          lanId: lanIdFromIp(clientIp(req)),
          ip: clientIp(req),
        });
      }

      case 'GET /api/devices': {
        const { user } = requireUser(req);
        return sendJson(res, 200, { devices: signaling.deviceList(user) });
      }

      case 'POST /api/device/rename': {
        const { user } = requireUser(req);
        const body = await readJsonBody(req);
        const name = cleanText(body.name, 32);
        if (!name) throw Object.assign(new Error('设备名不能为空'), { status: 400 });
        const device = store.renameDevice(user, String(body.deviceId || ''), name);
        if (!device) throw Object.assign(new Error('设备不存在'), { status: 404 });
        signaling.broadcastDevices(user.id);
        return sendJson(res, 200, { device });
      }

      case 'POST /api/device/forget': {
        const { user } = requireUser(req);
        const body = await readJsonBody(req);
        const deviceId = String(body.deviceId || '');
        signaling.kickDevice(deviceId, 'unbound');
        const removed = store.forgetDevice(user, deviceId);
        signaling.broadcastDevices(user.id);
        return sendJson(res, 200, { ok: removed });
      }

      // 仅本机可调用的关闭接口（stop.bat / stop.sh 使用）
      case 'POST /api/local/shutdown': {
        if (!isLoopback(req)) {
          throw Object.assign(new Error('仅允许在本机调用'), { status: 403, code: 'forbidden' });
        }
        sendJson(res, 200, { ok: true, message: 'closing' });
        setTimeout(() => {
          if (shutdownHook) shutdownHook();
          else process.exit(0);
        }, 30);
        return;
      }

      default:
        return sendJson(res, 404, { error: '接口不存在' });
    }
  } catch (err) {
    const status = err.status || 500;
    if (status >= 500) console.error('[api]', route, err);
    return sendJson(res, status, { error: err.message || '服务器内部错误', code: err.code });
  }
}

module.exports = { handleApi, setShutdownHook };
