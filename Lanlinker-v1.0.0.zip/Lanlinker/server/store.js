'use strict';

/**
 * 极简 JSON 文件存储：用户、设备绑定关系、登录会话。
 * 数据文件：data/db.json（自动创建）
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DATA_DIR = process.env.LANLINKER_DATA_DIR || path.join(__dirname, '..', 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');

const SESSION_TTL = 30 * 24 * 60 * 60 * 1000; // 30 天
const MAX_DEVICES_PER_USER = 50;
const SCRYPT_KEYLEN = 64;

let db = { users: [], sessions: [] };
let saveTimer = null;

function load() {
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    if (fs.existsSync(DB_FILE)) {
      const parsed = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
      db = { users: parsed.users || [], sessions: parsed.sessions || [] };
    }
  } catch (err) {
    console.error('[store] 数据文件读取失败，已重置为空数据：', err.message);
    db = { users: [], sessions: [] };
  }
  const now = Date.now();
  db.sessions = db.sessions.filter((s) => s && s.expiresAt > now);
  for (const user of db.users) if (!Array.isArray(user.devices)) user.devices = [];
  saveNow();
}

function saveNow() {
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    const tmp = `${DB_FILE}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(db, null, 2), 'utf8');
    fs.renameSync(tmp, DB_FILE);
  } catch (err) {
    console.error('[store] 数据写入失败：', err.message);
  }
}

function save() {
  if (saveTimer) return;
  saveTimer = setTimeout(() => {
    saveTimer = null;
    saveNow();
  }, 150);
}

/* ------------------------------ 账号 ------------------------------ */

function normalizeName(username) {
  return String(username || '').trim().toLowerCase();
}

function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(String(password), salt, SCRYPT_KEYLEN).toString('hex');
  return { salt, hash };
}

function verifyPassword(user, password) {
  try {
    const calc = crypto.scryptSync(String(password), user.salt, SCRYPT_KEYLEN);
    const known = Buffer.from(user.hash, 'hex');
    return calc.length === known.length && crypto.timingSafeEqual(calc, known);
  } catch {
    return false;
  }
}

function findUserByName(username) {
  const key = normalizeName(username);
  return db.users.find((u) => u.key === key) || null;
}

function findUserById(id) {
  return db.users.find((u) => u.id === id) || null;
}

function createUser(username, password) {
  const display = String(username || '').trim();
  if (findUserByName(display)) {
    throw Object.assign(new Error('该账号已被注册'), { status: 409, code: 'username_taken' });
  }
  const { salt, hash } = hashPassword(password);
  const user = {
    id: crypto.randomUUID(),
    username: display,
    key: normalizeName(display),
    salt,
    hash,
    createdAt: Date.now(),
    devices: [],
  };
  db.users.push(user);
  save();
  return user;
}

/* ------------------------------ 会话 ------------------------------ */

function createSession(userId) {
  const token = crypto.randomBytes(32).toString('hex');
  const now = Date.now();
  db.sessions.push({ token, userId, createdAt: now, expiresAt: now + SESSION_TTL });
  // 单账号最多保留 40 个有效会话
  const mine = db.sessions.filter((s) => s.userId === userId);
  if (mine.length > 40) {
    const drop = new Set(mine.sort((a, b) => a.createdAt - b.createdAt).slice(0, mine.length - 40).map((s) => s.token));
    db.sessions = db.sessions.filter((s) => !drop.has(s.token));
  }
  save();
  return token;
}

function getUserByToken(token) {
  if (!token) return null;
  const session = db.sessions.find((s) => s.token === token);
  if (!session) return null;
  if (session.expiresAt <= Date.now()) {
    deleteSession(token);
    return null;
  }
  return findUserById(session.userId);
}

function deleteSession(token) {
  const before = db.sessions.length;
  db.sessions = db.sessions.filter((s) => s.token !== token);
  if (db.sessions.length !== before) save();
}

/* ------------------------------ 设备 ------------------------------ */

/** 设备登录时自动绑定（已存在则更新信息） */
function upsertDevice(user, { id, name, platform }) {
  let device = user.devices.find((d) => d.id === id);
  const now = Date.now();
  if (device) {
    if (name) device.name = name;
    if (platform) device.platform = platform;
    device.lastSeen = now;
  } else {
    device = {
      id,
      name: name || '未命名设备',
      platform: platform || '',
      createdAt: now,
      lastSeen: now,
    };
    user.devices.push(device);
    if (user.devices.length > MAX_DEVICES_PER_USER) {
      user.devices.sort((a, b) => (b.lastSeen || 0) - (a.lastSeen || 0));
      user.devices = user.devices.slice(0, MAX_DEVICES_PER_USER);
    }
  }
  save();
  return device;
}

function renameDevice(user, deviceId, name) {
  const device = user.devices.find((d) => d.id === deviceId);
  if (!device) return null;
  device.name = name;
  save();
  return device;
}

function forgetDevice(user, deviceId) {
  const before = user.devices.length;
  user.devices = user.devices.filter((d) => d.id !== deviceId);
  const removed = user.devices.length !== before;
  if (removed) save();
  return removed;
}

function touchDevice(user, deviceId) {
  const device = user.devices.find((d) => d.id === deviceId);
  if (device) {
    device.lastSeen = Date.now();
    save();
  }
}

function publicUser(user) {
  return { id: user.id, username: user.username, createdAt: user.createdAt };
}

module.exports = {
  load,
  save,
  saveNow,
  createUser,
  findUserByName,
  findUserById,
  verifyPassword,
  createSession,
  getUserByToken,
  deleteSession,
  upsertDevice,
  renameDevice,
  forgetDevice,
  touchDevice,
  publicUser,
};
