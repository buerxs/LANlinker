'use strict';

/**
 * 信令中心：
 *  1. 设备登录后自动绑定到账号（无需手动配对）
 *  2. 维护在线设备表，任何变化即时推送给该账号的所有设备
 *  3. 转发 WebRTC 信令（offer / answer / candidate）
 *  4. P2P 不可用时，为纯文字消息提供服务器兜底中转
 */

const store = require('./store');
const { attachUpgrade } = require('./wsproto');
const { normalizeIp, lanIdFromIp, cleanText } = require('./util');

const DEVICE_ID_RE = /^[A-Za-z0-9_-]{8,64}$/;
const HELLO_TIMEOUT = 10_000;
const HEARTBEAT_INTERVAL = 25_000;

/** deviceId -> ctx */
const conns = new Map();
/** userId -> Set<deviceId> */
const byUser = new Map();

function addConn(ctx) {
  conns.set(ctx.deviceId, ctx);
  if (!byUser.has(ctx.userId)) byUser.set(ctx.userId, new Set());
  byUser.get(ctx.userId).add(ctx.deviceId);
}

function removeConn(ctx) {
  if (conns.get(ctx.deviceId) === ctx) conns.delete(ctx.deviceId);
  const set = byUser.get(ctx.userId);
  if (set) {
    set.delete(ctx.deviceId);
    if (!set.size) byUser.delete(ctx.userId);
  }
}

/** 组装某账号的完整设备列表（已绑定设备 + 在线状态 + 局域网信息） */
function deviceList(user) {
  const online = byUser.get(user.id) || new Set();
  return user.devices
    .map((device) => {
      const ctx = online.has(device.id) ? conns.get(device.id) : null;
      return {
        id: device.id,
        name: device.name,
        platform: device.platform || '',
        online: Boolean(ctx),
        lanId: ctx ? ctx.lanId : null,
        ip: ctx ? ctx.ip : null,
        lastSeen: ctx ? Date.now() : device.lastSeen || device.createdAt,
        boundAt: device.createdAt,
      };
    })
    .sort((a, b) => {
      if (a.online !== b.online) return a.online ? -1 : 1;
      return (b.lastSeen || 0) - (a.lastSeen || 0);
    });
}

function broadcastDevices(userId) {
  const user = store.findUserById(userId);
  if (!user) return;
  const list = deviceList(user);
  const set = byUser.get(userId);
  if (!set) return;
  for (const deviceId of set) {
    const ctx = conns.get(deviceId);
    if (!ctx) continue;
    ctx.conn.sendJson({
      t: 'devices',
      self: deviceId,
      lanId: ctx.lanId,
      devices: list.map((d) => ({ ...d, self: d.id === deviceId, sameLan: d.online && d.lanId === ctx.lanId })),
    });
  }
}

function kickDevice(deviceId, reason) {
  const ctx = conns.get(deviceId);
  if (!ctx) return false;
  ctx.conn.sendJson({ t: 'kicked', reason });
  ctx.conn.close(4001, reason);
  removeConn(ctx);
  return true;
}

/** 关闭全部在线连接，供服务优雅退出时调用 */
function closeAll(reason = 'server_shutdown') {
  for (const ctx of [...conns.values()]) {
    try {
      ctx.conn.close(4001, reason);
    } catch {
      /* 忽略单个连接关闭失败 */
    }
  }
  conns.clear();
  byUser.clear();
}

function setup(conn, req) {
  const ip = normalizeIp(req.socket.remoteAddress);
  const lanId = lanIdFromIp(ip);
  /** @type {{conn:any,userId:string,deviceId:string,lanId:string,ip:string}|null} */
  let ctx = null;

  const helloTimer = setTimeout(() => {
    if (!ctx) conn.close(4000, 'hello timeout');
  }, HELLO_TIMEOUT);

  conn.on('message', (raw) => {
    let msg;
    try {
      msg = JSON.parse(raw);
    } catch {
      return;
    }
    if (!msg || typeof msg.t !== 'string') return;

    if (msg.t === 'hello') {
      if (ctx) return;
      const user = store.getUserByToken(String(msg.token || ''));
      if (!user) {
        conn.sendJson({ t: 'error', code: 'unauthorized', message: '登录状态已失效，请重新登录' });
        conn.close(4003, 'unauthorized');
        return;
      }
      const deviceId = String(msg.deviceId || '');
      if (!DEVICE_ID_RE.test(deviceId)) {
        conn.sendJson({ t: 'error', code: 'bad_device', message: '设备标识不合法' });
        conn.close(4004, 'bad device id');
        return;
      }
      const existing = conns.get(deviceId);
      if (existing && existing.conn !== conn) {
        if (msg.takeover) {
          existing.conn.sendJson({ t: 'kicked', reason: 'takeover' });
          existing.conn.close(4001, 'takeover');
          removeConn(existing);
        } else {
          conn.sendJson({
            t: 'error',
            code: 'device_busy',
            message: '该设备已在其他窗口连接，可选择「在此窗口接管」',
          });
          conn.close(4009, 'device busy');
          return;
        }
      }

      const name = cleanText(msg.name, 32) || '未命名设备';
      const platform = cleanText(msg.platform, 48);
      // 关键：登录即自动绑定设备
      const device = store.upsertDevice(user, { id: deviceId, name, platform });

      clearTimeout(helloTimer);
      ctx = { conn, userId: user.id, deviceId, lanId, ip };
      addConn(ctx);

      conn.sendJson({
        t: 'welcome',
        self: { deviceId, name: device.name, platform: device.platform },
        user: store.publicUser(user),
        lanId,
        ip,
        serverTime: Date.now(),
      });
      broadcastDevices(user.id);
      return;
    }

    if (!ctx) return; // 未完成 hello 的连接不处理其它消息

    switch (msg.t) {
      case 'ping':
        conn.sendJson({ t: 'pong', ts: Date.now() });
        return;

      case 'devices': {
        const user = store.findUserById(ctx.userId);
        if (user) broadcastDevices(user.id);
        return;
      }

      case 'rename': {
        const user = store.findUserById(ctx.userId);
        const name = cleanText(msg.name, 32);
        if (user && name) {
          store.renameDevice(user, ctx.deviceId, name);
          broadcastDevices(user.id);
        }
        return;
      }

      // WebRTC 信令 / 文字兜底中转：只允许同账号设备之间互发
      case 'signal':
      case 'relay': {
        const to = String(msg.to || '');
        const target = conns.get(to);
        if (!target || target.userId !== ctx.userId) {
          conn.sendJson({ t: 'peer-gone', peer: to, kind: msg.t });
          return;
        }
        target.conn.sendJson({ t: msg.t, from: ctx.deviceId, payload: msg.payload });
        return;
      }

      default:
        return;
    }
  });

  conn.on('close', () => {
    clearTimeout(helloTimer);
    if (!ctx) return;
    const user = store.findUserById(ctx.userId);
    removeConn(ctx);
    if (user) {
      store.touchDevice(user, ctx.deviceId);
      broadcastDevices(user.id);
    }
    // 通知正在与其通话的设备
    for (const other of conns.values()) {
      if (other.userId === ctx.userId) {
        other.conn.sendJson({ t: 'peer-offline', peer: ctx.deviceId });
      }
    }
  });
}

let heartbeatTimer = null;

function attach(server) {
  attachUpgrade(server, '/ws', setup);
  if (heartbeatTimer) clearInterval(heartbeatTimer);
  heartbeatTimer = setInterval(() => {
    for (const ctx of Array.from(conns.values())) {
      if (!ctx.conn.isAlive) {
        ctx.conn.destroy();
        continue;
      }
      ctx.conn.isAlive = false;
      ctx.conn.ping();
    }
  }, HEARTBEAT_INTERVAL);
  heartbeatTimer.unref?.();
}

function stats() {
  return { online: conns.size, accounts: byUser.size };
}

module.exports = { attach, deviceList, broadcastDevices, kickDevice, closeAll, stats };
