'use strict';

/**
 * 零依赖的 WebSocket（RFC 6455）服务端实现。
 * 只需要支持文本帧（本项目的信令与控制消息都是 JSON），
 * 文件本体通过 WebRTC DataChannel 点对点传输，不经过这里。
 */

const crypto = require('crypto');
const { EventEmitter } = require('events');

const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
const MAX_MESSAGE = 512 * 1024; // 单条消息上限，SDP 远小于此值

const OP_CONT = 0x0;
const OP_TEXT = 0x1;
const OP_BINARY = 0x2;
const OP_CLOSE = 0x8;
const OP_PING = 0x9;
const OP_PONG = 0xa;

class WsConn extends EventEmitter {
  constructor(socket, req) {
    super();
    this.socket = socket;
    this.req = req;
    this.buf = Buffer.alloc(0);
    this.closed = false;
    this.isAlive = true;
    this.fragOpcode = 0;
    this.fragChunks = [];
    this.fragSize = 0;

    socket.on('data', (chunk) => this._receive(chunk));
    socket.on('error', () => this.destroy());
    socket.on('close', () => this._finish());
    socket.on('end', () => this.destroy());
  }

  get remoteAddress() {
    return this.socket.remoteAddress;
  }

  _finish() {
    if (this.closed) return;
    this.closed = true;
    this.emit('close');
  }

  _receive(chunk) {
    if (this.closed) return;
    this.buf = this.buf.length ? Buffer.concat([this.buf, chunk]) : chunk;
    try {
      this._parse();
    } catch (err) {
      this.close(1002, 'protocol error');
    }
  }

  _parse() {
    let buf = this.buf;
    for (;;) {
      if (buf.length < 2) break;
      const b0 = buf[0];
      const b1 = buf[1];
      const fin = (b0 & 0x80) !== 0;
      const opcode = b0 & 0x0f;
      const masked = (b1 & 0x80) !== 0;
      let len = b1 & 0x7f;
      let offset = 2;

      if (len === 126) {
        if (buf.length < 4) break;
        len = buf.readUInt16BE(2);
        offset = 4;
      } else if (len === 127) {
        if (buf.length < 10) break;
        const big = buf.readBigUInt64BE(2);
        if (big > BigInt(MAX_MESSAGE)) {
          this.close(1009, 'message too big');
          return;
        }
        len = Number(big);
        offset = 10;
      }

      const maskStart = offset;
      const dataStart = masked ? offset + 4 : offset;
      if (buf.length < dataStart + len) break;

      let payload = buf.subarray(dataStart, dataStart + len);
      if (masked) {
        const mask = buf.subarray(maskStart, maskStart + 4);
        const out = Buffer.allocUnsafe(len);
        for (let i = 0; i < len; i++) out[i] = payload[i] ^ mask[i & 3];
        payload = out;
      } else {
        payload = Buffer.from(payload);
      }

      buf = buf.subarray(dataStart + len);
      this.buf = buf;
      this._frame(fin, opcode, payload);
      if (this.closed) return;
    }
    this.buf = buf;
  }

  _frame(fin, opcode, payload) {
    if (opcode === OP_CLOSE) {
      this.close(1000, '');
      return;
    }
    if (opcode === OP_PING) {
      this._write(OP_PONG, payload);
      return;
    }
    if (opcode === OP_PONG) {
      this.isAlive = true;
      return;
    }

    if (opcode === OP_CONT) {
      if (!this.fragOpcode) {
        this.close(1002, 'unexpected continuation');
        return;
      }
      this.fragSize += payload.length;
      if (this.fragSize > MAX_MESSAGE) {
        this.close(1009, 'message too big');
        return;
      }
      this.fragChunks.push(payload);
      if (fin) {
        const full = Buffer.concat(this.fragChunks);
        const op = this.fragOpcode;
        this.fragOpcode = 0;
        this.fragChunks = [];
        this.fragSize = 0;
        this._deliver(op, full);
      }
      return;
    }

    if (opcode !== OP_TEXT && opcode !== OP_BINARY) {
      this.close(1003, 'unsupported opcode');
      return;
    }

    if (!fin) {
      this.fragOpcode = opcode;
      this.fragChunks = [payload];
      this.fragSize = payload.length;
      return;
    }
    if (payload.length > MAX_MESSAGE) {
      this.close(1009, 'message too big');
      return;
    }
    this._deliver(opcode, payload);
  }

  _deliver(opcode, payload) {
    this.isAlive = true;
    if (opcode === OP_TEXT) {
      this.emit('message', payload.toString('utf8'));
    } else {
      this.emit('binary', payload);
    }
  }

  _write(opcode, payload) {
    if (this.closed || this.socket.destroyed) return;
    const len = payload.length;
    let header;
    if (len < 126) {
      header = Buffer.allocUnsafe(2);
      header[1] = len;
    } else if (len < 65536) {
      header = Buffer.allocUnsafe(4);
      header[1] = 126;
      header.writeUInt16BE(len, 2);
    } else {
      header = Buffer.allocUnsafe(10);
      header[1] = 127;
      header.writeBigUInt64BE(BigInt(len), 2);
    }
    header[0] = 0x80 | opcode;
    try {
      this.socket.write(header);
      if (len) this.socket.write(payload);
    } catch {
      this.destroy();
    }
  }

  send(text) {
    this._write(OP_TEXT, Buffer.from(String(text), 'utf8'));
  }

  sendJson(obj) {
    this.send(JSON.stringify(obj));
  }

  ping() {
    this._write(OP_PING, Buffer.alloc(0));
  }

  close(code = 1000, reason = '') {
    if (this.closed) return;
    const reasonBuf = Buffer.from(String(reason), 'utf8');
    const payload = Buffer.allocUnsafe(2 + reasonBuf.length);
    payload.writeUInt16BE(code, 0);
    reasonBuf.copy(payload, 2);
    this._write(OP_CLOSE, payload);
    this._finish();
    try {
      this.socket.end();
    } catch {
      /* ignore */
    }
    setTimeout(() => {
      try {
        this.socket.destroy();
      } catch {
        /* ignore */
      }
    }, 200).unref?.();
  }

  destroy() {
    if (this.closed) {
      try {
        this.socket.destroy();
      } catch {
        /* ignore */
      }
      return;
    }
    this._finish();
    try {
      this.socket.destroy();
    } catch {
      /* ignore */
    }
  }
}

/**
 * 挂载 upgrade 处理。
 * @param {import('http').Server} server
 * @param {string} pathname 只接受该路径的握手
 * @param {(conn: WsConn, req: import('http').IncomingMessage) => void} onConnection
 */
function attachUpgrade(server, pathname, onConnection) {
  server.on('upgrade', (req, socket, head) => {
    const key = req.headers['sec-websocket-key'];
    const upgrade = String(req.headers['upgrade'] || '').toLowerCase();
    const url = new URL(req.url, 'http://localhost');

    if (upgrade !== 'websocket' || !key || url.pathname !== pathname) {
      socket.write('HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r\n');
      socket.destroy();
      return;
    }

    const accept = crypto.createHash('sha1').update(key + GUID).digest('base64');
    socket.write(
      'HTTP/1.1 101 Switching Protocols\r\n' +
        'Upgrade: websocket\r\n' +
        'Connection: Upgrade\r\n' +
        `Sec-WebSocket-Accept: ${accept}\r\n\r\n`
    );
    socket.setNoDelay(true);
    socket.setTimeout(0);

    const conn = new WsConn(socket, req);
    onConnection(conn, req);
    if (head && head.length) conn._receive(head);
  });
}

module.exports = { attachUpgrade, WsConn };
