'use strict';

const os = require('os');

/** 发送 JSON 响应 */
function sendJson(res, status, obj) {
  const body = Buffer.from(JSON.stringify(obj), 'utf8');
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': body.length,
    'Cache-Control': 'no-store',
  });
  res.end(body);
}

/** 读取请求体（带大小上限），解析为 JSON */
function readJsonBody(req, limit = 256 * 1024) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > limit) {
        reject(Object.assign(new Error('请求体过大'), { status: 413 }));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      if (!chunks.length) return resolve({});
      try {
        resolve(JSON.parse(Buffer.concat(chunks).toString('utf8')));
      } catch {
        reject(Object.assign(new Error('请求体不是合法的 JSON'), { status: 400 }));
      }
    });
    req.on('error', reject);
  });
}

/** 把 ::ffff:192.168.1.7 这类地址还原为 192.168.1.7 */
function normalizeIp(ip) {
  if (!ip) return '';
  let out = String(ip);
  if (out.startsWith('::ffff:')) out = out.slice(7);
  if (out === '::1') out = '127.0.0.1';
  const zone = out.indexOf('%');
  if (zone > -1) out = out.slice(0, zone);
  return out;
}

/**
 * 由 IP 推导「局域网标识」：IPv4 取 /24 网段，IPv6 取前 4 组。
 * 同一个 lanId 基本可认为处于同一个局域网。
 */
function lanIdFromIp(ip) {
  const addr = normalizeIp(ip);
  if (!addr) return 'unknown';
  if (addr.includes('.')) {
    const parts = addr.split('.');
    if (parts.length === 4) return parts.slice(0, 3).join('.') + '.0/24';
    return addr;
  }
  return addr.split(':').slice(0, 4).join(':') + '::/64';
}

/** 本机所有非回环 IPv4 地址 */
function localIPv4s() {
  const out = [];
  const nics = os.networkInterfaces();
  for (const name of Object.keys(nics)) {
    for (const info of nics[name] || []) {
      if (info.family === 'IPv4' && !info.internal) {
        out.push({ name, address: info.address });
      }
    }
  }
  return out;
}

/** 限制字符串长度并去掉控制字符 */
function cleanText(value, maxLen) {
  if (typeof value !== 'string') return '';
  // eslint-disable-next-line no-control-regex
  return value.replace(/[\u0000-\u001f\u007f]/g, '').trim().slice(0, maxLen);
}

/**
 * 是否允许开放注册。
 * 默认开启（on）。将环境变量 LANLINKER_ALLOW_REGISTER 设为 off / false / no / 0 时关闭，
 * 此时仅已存在账号可登录，新用户无法自助注册（适合公网只给特定人用的场景）。
 */
function isRegisterOpen() {
  const v = String(process.env.LANLINKER_ALLOW_REGISTER || 'on').trim().toLowerCase();
  return v !== 'off' && v !== 'false' && v !== 'no' && v !== '0';
}

module.exports = { sendJson, readJsonBody, normalizeIp, lanIdFromIp, localIPv4s, cleanText, isRegisterOpen };
