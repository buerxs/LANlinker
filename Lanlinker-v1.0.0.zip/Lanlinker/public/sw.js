/**
 * Service Worker：只在 HTTPS 下生效（浏览器限制）。
 * 策略是「全部直连、不做缓存」——本应用是局域网实时通信，
 * 静态资源缓存一旦过期不一致，反而会造成「改了代码不生效」的排查难题。
 * 它存在纯粹是为了满足 PWA 的可安装条件。
 */

self.addEventListener('install', () => self.skipWaiting());

self.addEventListener('activate', (event) => {
  event.waitUntil(self.clients.claim());
});

self.addEventListener('fetch', (event) => {
  // 什么都不缓存，全部直连网络
});
