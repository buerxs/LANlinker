import { api, session, deviceIdentity } from './api.js';
import { Signal } from './net.js';
import { PeerManager } from './peer.js';
import { Chat } from './chat.js';
import * as ui from './ui.js';
import { copyText } from './util.js';

const state = {
  user: null,
  identity: null,
  devices: [],
  activeId: null,
  unread: new Map(),
  lanId: null,
};

let dom = null;
let signal = null;
let peers = null;
let chat = null;
let authMode = 'login';
let refreshTimer = null;

/* ============================ 启动 ============================ */

async function boot() {
  dom = ui.initDom();
  bindAuthUI();
  bindAppUI();

  try {
    if (session.token) {
      try {
        const res = await api.session();
        startApp(res.user);
        return;
      } catch (err) {
        session.clear();
      }
    }
    ui.setAuthMode('login');
    ui.showAuth();
    // 根据服务端注册开关隐藏「注册」入口（公网可关闭开放注册）
    applyRegisterPolicy();
  } finally {
    const splash = document.getElementById('splash');
    if (splash) splash.remove();
  }
}

/* ============================ 登录 / 注册 ============================ */

/** 拉取服务端是否开放注册，关闭时前端隐藏注册入口 */
async function applyRegisterPolicy() {
  try {
    const info = await api.lanInfo();
    if (typeof info.registerOpen === 'boolean') ui.setRegisterOpen(info.registerOpen);
  } catch {
    /* 拿不到也不影响登录，保持默认（开放）即可 */
  }
}

function bindAuthUI() {
  dom.authTabs.addEventListener('click', (e) => {
    const tab = e.target.closest('.tab');
    if (!tab) return;
    authMode = tab.dataset.mode;
    ui.setAuthMode(authMode);
  });

  dom.authForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const username = dom.username.value.trim();
    const password = dom.password.value;
    ui.setAuthError('');

    if (!username || !password) return ui.setAuthError('请填写账号和密码');
    if (authMode === 'register') {
      if (password.length < 6) return ui.setAuthError('密码至少 6 位');
      if (password !== dom.confirm.value) return ui.setAuthError('两次输入的密码不一致');
      if (!dom.agree || !dom.agree.checked) return ui.setAuthError('请先阅读并勾选同意《使用条款》与合规承诺');
    }

    ui.setAuthBusy(true, authMode);
    try {
      const res = authMode === 'register'
        ? await api.register(username, password)
        : await api.login(username, password);
      session.save(res.token, dom.remember.checked);
      dom.password.value = '';
      dom.confirm.value = '';
      startApp(res.user);
    } catch (err) {
      ui.setAuthError(err.message || '操作失败，请重试');
    } finally {
      ui.setAuthBusy(false, authMode);
    }
  });
}

/* ============================ 主流程 ============================ */

/**
 * 取服务端当前的局域网地址并显示出来。
 * 局域网 IP 会随 DHCP 变化，显示实时地址比让用户去翻控制台靠谱。
 */
async function refreshLanAddress() {
  try {
    const info = await api.lanInfo();
    const url = info.primary || (info.urls && info.urls.length ? info.urls[0].url : '');
    if (url && dom.lanAddr && dom.lanAddr.textContent !== url) ui.hideQr(); // 地址变了就收起旧二维码
    ui.setLanAddress(url);
  } catch {
    ui.setLanAddress('');
  }
}

function startApp(user) {
  state.user = user;
  state.identity = deviceIdentity();
  state.devices = [];
  state.activeId = null;
  state.unread.clear();

  ui.setAccount({ username: user.username, lanId: '' });
  ui.setSelf({ name: state.identity.name, platform: state.identity.platform });
  ui.setWsState(false, '连接中');
  ui.showApp();
  refreshLanAddress();

  signal = new Signal();
  peers = new PeerManager({ signal, selfId: state.identity.id });
  chat = new Chat({ peers, signal });
  chat.setUser(user.id);

  wirePeers();
  wireChat();
  wireSignal();

  signal.connect({
    token: session.token,
    deviceId: state.identity.id,
    name: state.identity.name,
    platform: state.identity.platform,
  });

  if (refreshTimer) clearInterval(refreshTimer);
  refreshTimer = setInterval(renderDevices, 45_000);

  registerServiceWorker();

  if (state.identity.isolated) {
    ui.toast('已启用独立设备身份（?newdevice=1），方便在同一台电脑上测试', 'ok');
  }
}

/** 添加到主屏（PWA）。仅在 HTTPS 下注册成功，HTTP 下静默跳过 */
function registerServiceWorker() {
  if (location.protocol !== 'https:') return;
  if (!('serviceWorker' in navigator)) return;
  navigator.serviceWorker.register('/sw.js').catch(() => { /* 忽略，不影响使用 */ });
}

function renderDevices() {
  ui.renderDevices(state.devices, {
    activeId: state.activeId,
    unread: state.unread,
    stateOf: (id) => (peers ? peers.stateOf(id) : 'new'),
  });
}

function deviceById(id) {
  return state.devices.find((d) => d.id === id) || null;
}

function selectDevice(id) {
  const device = deviceById(id);
  if (!device) return;
  state.activeId = id;
  state.unread.delete(id);

  ui.openChatView(device, { mobile: ui.isMobile() });
  ui.renderMessages(chat.list(id));
  ui.setConnBadge(peers.stateOf(id));
  renderDevices();

  if (device.online) {
    peers.ensure(id);
  } else {
    ui.setConnBadge('closed');
  }
}

/* ============================ 事件接线 ============================ */

function wireSignal() {
  signal.on('state', (s) => {
    if (s === 'connecting') ui.setWsState(false, '连接中');
    else if (s === 'closed') ui.setWsState(false, '已断开');
  });

  signal.on('welcome', (msg) => {
    state.lanId = msg.lanId;
    ui.setWsState(true, '已连接');
    ui.setAccount({ username: msg.user.username, lanId: msg.lanId });
    ui.setSelf({ name: msg.self.name, platform: msg.self.platform, ip: msg.ip });
    peers.setSelf(msg.self.deviceId);
    refreshLanAddress(); // 断线重连时重新取一次，IP 变了也能显示最新地址
  });

  signal.on('devices', (msg) => {
    const prev = new Map(state.devices.map((d) => [d.id, d.online]));
    state.devices = msg.devices || [];
    renderDevices();

    for (const device of state.devices) {
      if (device.self) continue;
      const was = prev.get(device.id);
      if (device.online && was === false && device.id === state.activeId) {
        peers.ensure(device.id);
      }
    }

    if (state.activeId) {
      const active = deviceById(state.activeId);
      if (active) ui.openChatView(active);
    }
  });

  signal.on('signal', (msg) => {
    peers.handleSignal(msg.from, msg.payload);
  });

  signal.on('relay', (msg) => {
    chat.handleRelay(msg.from, msg.payload);
  });

  signal.on('peer-offline', (msg) => {
    chat.peerGone(msg.peer);
    peers.close(msg.peer);
    if (msg.peer === state.activeId) ui.setConnBadge('closed');
    renderDevices();
  });

  signal.on('peer-gone', () => {
    ui.toast('对方设备当前不在线', 'err');
  });

  signal.on('error', (msg) => {
    if (msg.code === 'unauthorized') {
      ui.toast('登录状态已失效，请重新登录', 'err');
      session.clear();
      signal.stop();
      setTimeout(() => location.reload(), 900);
      return;
    }
    if (msg.code === 'device_busy') {
      signal.stop();
      ui.setWsState(false, '未连接');
      const ok = window.confirm('该设备已在另一个窗口或标签页中连接。\n\n点击「确定」在当前窗口接管连接；\n点击「取消」保持另一个窗口继续使用。');
      if (ok) {
        signal.connect({ takeover: true });
      } else {
        ui.toast('已保留另一个窗口的连接，本页面处于未连接状态', '');
      }
      return;
    }
    ui.toast(msg.message || '服务器返回了一个错误', 'err');
  });

  signal.on('kicked', (msg) => {
    signal.stop();
    ui.setWsState(false, '已断开');
    if (msg.reason === 'takeover') ui.toast('连接已被同一设备的另一个窗口接管', 'err');
    else if (msg.reason === 'unbound') ui.toast('本设备已被解除绑定，刷新页面可重新绑定', 'err');
    else ui.toast('连接已被服务器关闭', 'err');
  });
}

function wirePeers() {
  peers.onState = (peerId, s) => {
    if (peerId === state.activeId) ui.setConnBadge(s);
    renderDevices();
  };
  peers.onData = (peerId, data) => chat.handleData(peerId, data);
  peers.onOpen = (peerId) => {
    const device = deviceById(peerId);
    chat.system(peerId, `已与「${device ? device.name : peerId}」建立点对点连接`);
  };
}

function wireChat() {
  chat.onAdd = (msg) => {
    if (msg.peer === state.activeId) {
      ui.appendMessage(msg);
      return;
    }
    if (msg.dir === 'in') {
      state.unread.set(msg.peer, (state.unread.get(msg.peer) || 0) + 1);
      const device = deviceById(msg.peer);
      const who = device ? device.name : '其它设备';
      ui.toast(msg.kind === 'file' ? `${who} 正在发送文件：${msg.name}` : `${who}：${msg.text.slice(0, 30)}`);
      renderDevices();
    }
  };
  chat.onUpdate = (msg) => {
    if (msg.peer === state.activeId) ui.updateMessage(msg);
  };
}

/* ============================ 界面交互 ============================ */

function bindAppUI() {
  dom.deviceList.addEventListener('click', async (e) => {
    const forget = e.target.closest('[data-act="forget"]');
    const li = e.target.closest('.device');
    if (!li) return;
    const id = li.dataset.id;

    if (forget) {
      e.stopPropagation();
      const device = deviceById(id);
      if (!window.confirm(`确定要解除绑定「${device ? device.name : id}」吗？\n该设备下次登录时会重新自动绑定。`)) return;
      try {
        await api.forgetDevice(id);
        if (state.activeId === id) {
          state.activeId = null;
          dom.chatInner.hidden = true;
          dom.chatEmpty.hidden = false;
          ui.closeChatView();
        }
        ui.toast('已解除绑定', 'ok');
      } catch (err) {
        ui.toast(err.message || '解绑失败', 'err');
      }
      return;
    }
    selectDevice(id);
  });

  dom.btnQr?.addEventListener('click', () => {
    const url = dom.lanAddr.textContent.trim();
    const shown = ui.toggleQr(url);
    if (!shown && dom.qrWrap.hidden) ui.toast('暂时无法生成二维码', 'err');
  });

  dom.btnCopyAddr?.addEventListener('click', async () => {
    const url = dom.lanAddr.textContent.trim();
    if (!url || url === '—') return;
    const ok = await copyText(url);
    ui.toast(ok ? '地址已复制，发给手机浏览器打开' : '复制失败，请手动选中地址', ok ? 'ok' : 'err');
  });

  dom.btnRename.addEventListener('click', async () => {
    const next = window.prompt('给这台设备起个名字', state.identity.name);
    if (!next) return;
    const name = next.trim().slice(0, 32);
    if (!name) return;
    try {
      await api.renameDevice(state.identity.id, name);
      state.identity.setName(name);
      signal.send({ t: 'rename', name });
      ui.setSelf({ name, platform: state.identity.platform });
      ui.toast('设备名已更新', 'ok');
    } catch (err) {
      ui.toast(err.message || '改名失败', 'err');
    }
  });

  dom.btnLogout.addEventListener('click', async () => {
    if (!window.confirm('退出登录后，本设备将从在线列表中消失，确定退出吗？')) return;
    try {
      await api.logout();
    } catch { /* ignore */ }
    session.clear();
    if (signal) signal.stop();
    if (peers) peers.closeAll();
    location.reload();
  });

  dom.btnBack.addEventListener('click', () => {
    ui.closeChatView();
  });

  dom.btnReconnect.addEventListener('click', () => {
    if (!state.activeId) return;
    peers.reconnect(state.activeId);
    ui.setConnBadge('connecting');
    ui.toast('正在重新建立点对点连接…');
  });

  // 发送文字
  dom.composer.addEventListener('submit', (e) => {
    e.preventDefault();
    sendCurrentText();
  });
  dom.inputText.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) {
      e.preventDefault();
      sendCurrentText();
    }
  });
  dom.inputText.addEventListener('input', () => ui.autoGrow(dom.inputText));

  // 发送文件
  dom.btnFile.addEventListener('click', () => dom.fileInput.click());
  dom.fileInput.addEventListener('change', () => {
    if (state.activeId && dom.fileInput.files.length) {
      chat.sendFiles(state.activeId, dom.fileInput.files);
    }
    dom.fileInput.value = '';
  });

  // 拖拽发送
  let dragDepth = 0;
  dom.chatInner.addEventListener('dragenter', (e) => {
    if (!state.activeId) return;
    e.preventDefault();
    dragDepth += 1;
    dom.dropMask.classList.add('show');
  });
  dom.chatInner.addEventListener('dragover', (e) => {
    if (!state.activeId) return;
    e.preventDefault();
  });
  dom.chatInner.addEventListener('dragleave', () => {
    dragDepth = Math.max(0, dragDepth - 1);
    if (!dragDepth) dom.dropMask.classList.remove('show');
  });
  dom.chatInner.addEventListener('drop', (e) => {
    e.preventDefault();
    dragDepth = 0;
    dom.dropMask.classList.remove('show');
    if (!state.activeId) return;
    const files = e.dataTransfer && e.dataTransfer.files;
    if (files && files.length) chat.sendFiles(state.activeId, files);
  });

  // 粘贴发送（截图直接粘贴）
  document.addEventListener('paste', (e) => {
    if (!state.activeId || dom.viewApp.hidden) return;
    const files = e.clipboardData ? Array.from(e.clipboardData.files || []) : [];
    if (files.length) {
      e.preventDefault();
      chat.sendFiles(state.activeId, files);
    }
  });

  // 消息内按钮
  dom.messages.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-act]');
    if (!btn) return;
    if (btn.dataset.act === 'cancel') chat.cancel(btn.dataset.id);
    if (btn.dataset.act === 'resend') dom.fileInput.click();
  });

  window.addEventListener('beforeunload', () => {
    if (peers) peers.closeAll();
  });
}

function sendCurrentText() {
  const text = dom.inputText.value.replace(/\s+$/, '');
  if (!text) return;
  if (!state.activeId) {
    ui.toast('请先在左侧选择一台设备', 'err');
    return;
  }
  const device = deviceById(state.activeId);
  if (device && !device.online) {
    ui.toast('对方设备当前离线，消息无法送达', 'err');
    return;
  }
  chat.sendText(state.activeId, text);
  dom.inputText.value = '';
  ui.autoGrow(dom.inputText);
  dom.inputText.focus();
}

boot().catch((err) => {
  console.error(err);
  ui.setAuthError('初始化失败：' + err.message);
  ui.showAuth();
});
