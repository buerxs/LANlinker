export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

/** 随机 ID（非安全上下文下 crypto.randomUUID 不可用，做了降级） */
export function randomId(bytes = 12) {
  const arr = new Uint8Array(bytes);
  if (window.crypto && typeof crypto.getRandomValues === 'function') {
    crypto.getRandomValues(arr);
  } else {
    for (let i = 0; i < bytes; i++) arr[i] = Math.floor(Math.random() * 256);
  }
  return Array.from(arr, (b) => b.toString(16).padStart(2, '0')).join('');
}

export function fmtBytes(n) {
  if (!Number.isFinite(n)) return '—';
  if (n < 1024) return `${n} B`;
  const units = ['KB', 'MB', 'GB', 'TB'];
  let i = -1;
  let v = n;
  do {
    v /= 1024;
    i++;
  } while (v >= 1024 && i < units.length - 1);
  return `${v.toFixed(v < 10 ? 2 : 1)} ${units[i]}`;
}

export function fmtSpeed(bytesPerSec) {
  if (!bytesPerSec || bytesPerSec < 1) return '';
  return `${fmtBytes(bytesPerSec)}/s`;
}

export function fmtClock(ts) {
  const d = new Date(ts);
  return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
}

export function fmtDay(ts) {
  const d = new Date(ts);
  const today = new Date();
  const same = d.toDateString() === today.toDateString();
  if (same) return '今天';
  const yest = new Date(today.getTime() - 86400000);
  if (d.toDateString() === yest.toDateString()) return '昨天';
  return `${d.getMonth() + 1}月${d.getDate()}日`;
}

export function fmtLastSeen(ts) {
  if (!ts) return '未连接过';
  const diff = Date.now() - ts;
  if (diff < 60_000) return '刚刚在线';
  if (diff < 3600_000) return `${Math.floor(diff / 60_000)} 分钟前在线`;
  if (diff < 86400_000) return `${Math.floor(diff / 3600_000)} 小时前在线`;
  return `${Math.floor(diff / 86400_000)} 天前在线`;
}

export function escapeHtml(str) {
  return String(str).replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  }[c]));
}

/** 文字消息渲染：转义 + 自动识别链接 */
export function renderText(text) {
  const safe = escapeHtml(text);
  return safe.replace(/(https?:\/\/[^\s<]+)/g, (m) => `<a href="${m}" target="_blank" rel="noreferrer noopener">${m}</a>`);
}

export function extLabel(name = '') {
  const m = /\.([A-Za-z0-9]{1,5})$/.exec(name);
  return m ? m[1].toUpperCase().slice(0, 4) : 'FILE';
}

/** 猜测当前设备的名称与平台，作为自动绑定时的默认设备名 */
export function detectDevice() {
  const ua = navigator.userAgent;
  let os = '设备';
  if (/Windows NT/i.test(ua)) os = 'Windows';
  else if (/Android/i.test(ua)) os = 'Android';
  else if (/(iPhone|iPod)/i.test(ua)) os = 'iPhone';
  else if (/iPad/i.test(ua)) os = 'iPad';
  else if (/Mac OS X/i.test(ua)) os = 'Mac';
  else if (/Linux/i.test(ua)) os = 'Linux';
  else if (/CrOS/i.test(ua)) os = 'ChromeOS';

  let browser = '浏览器';
  if (/Edg\//i.test(ua)) browser = 'Edge';
  else if (/OPR\//i.test(ua)) browser = 'Opera';
  else if (/Firefox\//i.test(ua)) browser = 'Firefox';
  else if (/Chrome\//i.test(ua)) browser = 'Chrome';
  else if (/Safari\//i.test(ua)) browser = 'Safari';

  return { os, browser, name: `${os} · ${browser}`, platform: `${os} / ${browser}` };
}

export function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

/** 复制文字到剪贴板：优先 Clipboard API，非安全上下文降级 execCommand */
export async function copyText(text) {
  try {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch { /* 降级 */ }
  try {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.cssText = 'position:fixed;opacity:0;top:0;left:0';
    document.body.appendChild(ta);
    ta.focus();
    ta.select();
    const ok = document.execCommand('copy');
    ta.remove();
    return ok;
  } catch {
    return false;
  }
}
