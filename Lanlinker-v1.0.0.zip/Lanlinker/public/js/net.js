/**
 * 与服务器的 WebSocket 连接：设备上线/绑定、在线设备实时刷新、WebRTC 信令通道。
 * 断线自动重连（指数退避），带心跳与看门狗。
 */

const HEARTBEAT = 20_000;
const WATCHDOG = 55_000;
const MAX_BACKOFF = 8_000;

export class Signal {
  constructor() {
    this.handlers = new Map();
    this.ws = null;
    this.opts = null;
    this.attempt = 0;
    this.stopped = false;
    this.lastMsgAt = 0;
    this.timer = null;
    this.retryTimer = null;
  }

  on(type, fn) {
    if (!this.handlers.has(type)) this.handlers.set(type, []);
    this.handlers.get(type).push(fn);
    return this;
  }

  emit(type, payload) {
    for (const fn of this.handlers.get(type) || []) {
      try {
        fn(payload);
      } catch (err) {
        console.error(`[signal:${type}]`, err);
      }
    }
  }

  get connected() {
    return Boolean(this.ws && this.ws.readyState === WebSocket.OPEN);
  }

  /** 兜底中转时用于背压控制 */
  get bufferedAmount() {
    return this.ws ? this.ws.bufferedAmount : 0;
  }

  connect(opts) {
    this.opts = { ...this.opts, ...opts };
    this.stopped = false;
    this.attempt = 0;
    this._open();
  }

  _url() {
    const scheme = location.protocol === 'https:' ? 'wss' : 'ws';
    return `${scheme}://${location.host}/ws`;
  }

  _open() {
    if (this.stopped) return;
    clearTimeout(this.retryTimer);
    if (this.ws) {
      try {
        this.ws.onclose = null;
        this.ws.close();
      } catch { /* ignore */ }
    }

    let ws;
    try {
      ws = new WebSocket(this._url());
    } catch (err) {
      this._scheduleRetry();
      return;
    }
    this.ws = ws;
    this.emit('state', 'connecting');

    ws.onopen = () => {
      this.attempt = 0;
      this.lastMsgAt = Date.now();
      const { token, deviceId, name, platform, takeover } = this.opts;
      ws.send(JSON.stringify({ t: 'hello', token, deviceId, name, platform, takeover: Boolean(takeover) }));
      // 接管只生效一次
      this.opts.takeover = false;
      this._startTimers();
    };

    ws.onmessage = (evt) => {
      this.lastMsgAt = Date.now();
      let msg;
      try {
        msg = JSON.parse(evt.data);
      } catch {
        return;
      }
      if (!msg || !msg.t) return;
      if (msg.t === 'pong') return;
      this.emit(msg.t, msg);
      this.emit('*', msg);
    };

    ws.onerror = () => { /* 交由 onclose 处理 */ };

    ws.onclose = () => {
      this._stopTimers();
      if (this.ws === ws) this.ws = null;
      this.emit('state', 'closed');
      if (!this.stopped) this._scheduleRetry();
    };
  }

  _startTimers() {
    this._stopTimers();
    this.timer = setInterval(() => {
      if (!this.connected) return;
      this.send({ t: 'ping' });
      if (Date.now() - this.lastMsgAt > WATCHDOG) {
        // 长时间无任何消息，主动重连
        try {
          this.ws.close();
        } catch { /* ignore */ }
      }
    }, HEARTBEAT);
  }

  _stopTimers() {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
  }

  _scheduleRetry() {
    this.attempt += 1;
    const delay = Math.min(MAX_BACKOFF, 500 * 2 ** Math.min(this.attempt - 1, 4));
    clearTimeout(this.retryTimer);
    this.retryTimer = setTimeout(() => this._open(), delay);
  }

  send(obj) {
    if (!this.connected) return false;
    try {
      this.ws.send(JSON.stringify(obj));
      return true;
    } catch {
      return false;
    }
  }

  /** 停止重连并断开（退出登录 / 被踢时使用） */
  stop() {
    this.stopped = true;
    clearTimeout(this.retryTimer);
    this._stopTimers();
    if (this.ws) {
      try {
        this.ws.close();
      } catch { /* ignore */ }
      this.ws = null;
    }
  }
}
