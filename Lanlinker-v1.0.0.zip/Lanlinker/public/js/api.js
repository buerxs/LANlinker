import { randomId, detectDevice } from './util.js';

const TOKEN_KEY = 'lanlinker.token';
const DEVICE_KEY = 'lanlinker.deviceId';
const DEVNAME_KEY = 'lanlinker.deviceName';

/* ------------ 登录态 ------------ */
export const session = {
  get token() {
    return localStorage.getItem(TOKEN_KEY) || sessionStorage.getItem(TOKEN_KEY) || '';
  },
  save(token, persist = true) {
    if (persist) localStorage.setItem(TOKEN_KEY, token);
    else sessionStorage.setItem(TOKEN_KEY, token);
  },
  clear() {
    localStorage.removeItem(TOKEN_KEY);
    sessionStorage.removeItem(TOKEN_KEY);
  },
};

/**
 * 本设备的稳定标识：存在 localStorage 里，登录后由服务端自动绑定到账号。
 * 带 ?newdevice=1 打开时，会在当前标签页生成一个临时的独立设备身份（方便单机测试）。
 */
export function deviceIdentity() {
  const params = new URLSearchParams(location.search);
  const isolated = params.get('newdevice') === '1';
  const store = isolated ? sessionStorage : localStorage;
  let id = store.getItem(DEVICE_KEY);
  if (!id) {
    id = randomId(16);
    store.setItem(DEVICE_KEY, id);
  }
  const detected = detectDevice();
  let name = store.getItem(DEVNAME_KEY);
  if (!name) {
    name = isolated ? `${detected.name} (副本)` : detected.name;
    store.setItem(DEVNAME_KEY, name);
  }
  return {
    id,
    name,
    platform: detected.platform,
    isolated,
    setName(next) {
      store.setItem(DEVNAME_KEY, next);
      this.name = next;
    },
  };
}

/* ------------ HTTP ------------ */
async function request(path, { method = 'GET', body } = {}) {
  const headers = {};
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  const token = session.token;
  if (token) headers['Authorization'] = `Bearer ${token}`;

  const res = await fetch(path, {
    method,
    headers,
    body: body === undefined ? undefined : JSON.stringify(body),
  });

  let data = null;
  try {
    data = await res.json();
  } catch {
    data = null;
  }
  if (!res.ok) {
    const err = new Error((data && data.error) || `请求失败（${res.status}）`);
    err.status = res.status;
    err.code = data && data.code;
    throw err;
  }
  return data || {};
}

export const api = {
  register: (username, password) => request('/api/register', { method: 'POST', body: { username, password } }),
  login: (username, password) => request('/api/login', { method: 'POST', body: { username, password } }),
  logout: () => request('/api/logout', { method: 'POST', body: {} }),
  session: () => request('/api/session'),
  devices: () => request('/api/devices'),
  renameDevice: (deviceId, name) => request('/api/device/rename', { method: 'POST', body: { deviceId, name } }),
  forgetDevice: (deviceId) => request('/api/device/forget', { method: 'POST', body: { deviceId } }),
  /** 当前服务的局域网访问地址（IP 变了也不会认错，给手机用） */
  lanInfo: () => request('/api/lan-info'),
};
