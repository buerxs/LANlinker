/**
 * WebRTC 点对点连接管理。
 *
 * 为了彻底避免双方同时发起造成的 offer 冲突（glare），这里用确定性分工：
 *   deviceId 字典序较小的一方永远是「发起方」，负责 createOffer 并创建 DataChannel；
 *   另一方想要连接时，只需通过信令请求对方发起。
 * 所有信令按到达顺序串行处理，candidate 在 remoteDescription 就绪前先缓存。
 */

const RTC_CONFIG = {
  iceServers: [{ urls: ['stun:stun.l.google.com:19302'] }],
  // 局域网内主要依赖 host 候选，没有外网也能连通
  iceTransportPolicy: 'all',
};

class Link {
  constructor(manager, peerId) {
    this.mgr = manager;
    this.peerId = peerId;
    this.offerer = String(manager.selfId) < String(peerId);
    this.pc = null;
    this.dc = null;
    this.state = 'new';
    this.queue = Promise.resolve();
    this.pendingCandidates = [];
    this.hasRemote = false;
    this.disposed = false;
  }

  setState(next) {
    if (this.state === next || this.disposed) return;
    this.state = next;
    this.mgr.onState(this.peerId, next);
  }

  ensurePc() {
    if (this.pc) return this.pc;
    const pc = new RTCPeerConnection(RTC_CONFIG);
    this.pc = pc;

    pc.onicecandidate = ({ candidate }) => {
      if (candidate) this.signal({ candidate: candidate.toJSON ? candidate.toJSON() : candidate });
    };

    pc.ondatachannel = (evt) => {
      this.bindChannel(evt.channel);
    };

    pc.onconnectionstatechange = () => {
      const s = pc.connectionState;
      if (s === 'connected') {
        if (this.dc && this.dc.readyState === 'open') this.setState('connected');
      } else if (s === 'connecting' || s === 'new') {
        this.setState('connecting');
      } else if (s === 'disconnected') {
        this.setState('connecting');
      } else if (s === 'failed') {
        this.setState('failed');
      } else if (s === 'closed') {
        this.setState('closed');
      }
    };

    pc.oniceconnectionstatechange = () => {
      if (pc.iceConnectionState === 'failed') this.setState('failed');
    };

    return pc;
  }

  bindChannel(dc) {
    this.dc = dc;
    dc.binaryType = 'arraybuffer';
    dc.onopen = () => {
      this.setState('connected');
      this.mgr.onOpen(this.peerId);
    };
    dc.onclose = () => {
      if (this.state === 'connected') this.setState('closed');
    };
    dc.onerror = (evt) => {
      // Firefox 在对端关闭时也会触发 error，仅记录
      console.warn('[dc error]', this.peerId, evt && evt.error ? evt.error.message : evt);
    };
    dc.onmessage = (evt) => this.mgr.onData(this.peerId, evt.data);
  }

  signal(payload) {
    this.mgr.signal.send({ t: 'signal', to: this.peerId, payload });
  }

  /** 主动建立连接 */
  connect() {
    if (this.disposed) return;
    this.setState('connecting');
    if (this.offerer) {
      this.makeOffer();
    } else {
      // 请对方（发起方）向我发 offer
      this.signal({ req: 'connect' });
    }
  }

  async makeOffer() {
    const pc = this.ensurePc();
    if (!this.dc) {
      this.bindChannel(pc.createDataChannel('lanlinker', { ordered: true }));
    }
    try {
      const offer = await pc.createOffer();
      if (pc.signalingState !== 'stable') return;
      await pc.setLocalDescription(offer);
      this.signal({ description: { type: offer.type, sdp: offer.sdp } });
    } catch (err) {
      console.error('[makeOffer]', err);
      this.setState('failed');
    }
  }

  handleSignal(payload) {
    this.queue = this.queue.then(() => this._handleSignal(payload)).catch((err) => {
      console.error('[handleSignal]', err);
    });
  }

  async _handleSignal(payload) {
    if (this.disposed || !payload) return;

    if (payload.req === 'connect') {
      if (this.offerer) {
        if (this.state !== 'connected') {
          this.setState('connecting');
          await this.makeOffer();
        }
      }
      return;
    }

    const pc = this.ensurePc();

    if (payload.description) {
      const desc = payload.description;
      if (desc.type === 'offer') {
        if (pc.signalingState !== 'stable') {
          // 极少见：本地有未完成的 offer，回滚后接受对方的
          try {
            await pc.setLocalDescription({ type: 'rollback' });
          } catch {
            /* 部分浏览器不支持显式回滚，交给下面的 setRemoteDescription 隐式处理 */
          }
        }
        await pc.setRemoteDescription(desc);
        this.hasRemote = true;
        await this.flushCandidates();
        const answer = await pc.createAnswer();
        await pc.setLocalDescription(answer);
        this.signal({ description: { type: answer.type, sdp: answer.sdp } });
      } else if (desc.type === 'answer') {
        if (pc.signalingState !== 'have-local-offer') return;
        await pc.setRemoteDescription(desc);
        this.hasRemote = true;
        await this.flushCandidates();
      }
      return;
    }

    if (payload.candidate) {
      if (!this.hasRemote) {
        this.pendingCandidates.push(payload.candidate);
        return;
      }
      try {
        await pc.addIceCandidate(payload.candidate);
      } catch (err) {
        console.warn('[addIceCandidate]', err.message);
      }
    }
  }

  async flushCandidates() {
    const list = this.pendingCandidates;
    this.pendingCandidates = [];
    for (const c of list) {
      try {
        await this.pc.addIceCandidate(c);
      } catch (err) {
        console.warn('[flushCandidate]', err.message);
      }
    }
  }

  get open() {
    return Boolean(this.dc && this.dc.readyState === 'open');
  }

  send(data) {
    if (!this.open) return false;
    this.dc.send(data);
    return true;
  }

  dispose(silent = false) {
    const dc = this.dc;
    const pc = this.pc;
    this.dc = null;
    this.pc = null;
    if (pc) {
      pc.onicecandidate = null;
      pc.ondatachannel = null;
      pc.onconnectionstatechange = null;
      pc.oniceconnectionstatechange = null;
    }
    try {
      if (dc) dc.close();
    } catch { /* ignore */ }
    try {
      if (pc) pc.close();
    } catch { /* ignore */ }
    if (!silent) this.setState('closed');
    this.disposed = true;
  }
}

export class PeerManager {
  constructor({ signal, selfId }) {
    this.signal = signal;
    this.selfId = selfId;
    this.links = new Map();
    this.onState = () => {};
    this.onData = () => {};
    this.onOpen = () => {};
  }

  setSelf(selfId) {
    this.selfId = selfId;
  }

  get(peerId) {
    return this.links.get(peerId) || null;
  }

  stateOf(peerId) {
    const link = this.links.get(peerId);
    return link ? link.state : 'new';
  }

  isOpen(peerId) {
    const link = this.links.get(peerId);
    return Boolean(link && link.open);
  }

  ensure(peerId) {
    let link = this.links.get(peerId);
    if (!link || link.disposed) {
      link = new Link(this, peerId);
      this.links.set(peerId, link);
      link.connect();
      return link;
    }
    if (link.state === 'new' || link.state === 'failed' || link.state === 'closed') {
      link.connect();
    }
    return link;
  }

  reconnect(peerId) {
    const link = this.links.get(peerId);
    if (link) {
      link.dispose(true);
      this.links.delete(peerId);
    }
    return this.ensure(peerId);
  }

  handleSignal(from, payload) {
    let link = this.links.get(from);
    if (!link || link.disposed) {
      link = new Link(this, from);
      this.links.set(from, link);
      link.setState('connecting');
    }
    link.handleSignal(payload);
  }

  close(peerId) {
    const link = this.links.get(peerId);
    if (!link) return;
    link.dispose();
    this.links.delete(peerId);
  }

  closeAll() {
    for (const id of Array.from(this.links.keys())) this.close(id);
  }

  send(peerId, data) {
    const link = this.links.get(peerId);
    if (!link) return false;
    return link.send(data);
  }
}
