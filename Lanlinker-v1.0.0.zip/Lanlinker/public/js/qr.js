/**
 * 极简 QR 码生成器（零依赖）
 *
 * 只做本项目需要的最小子集：字节模式（UTF-8）、纠错等级 M、版本 1-10。
 * 输出二维布尔矩阵（true = 深色模块），由 UI 层自己绘制。
 *
 * 实现依据 ISO/IEC 18004，算法结构参考 Nayuki 的 QR Code generator。
 * 正确性由 scripts/qr-test.js 与 Python segno 库的输出逐格比对来保证。
 */

/* ---------------- GF(256) ---------------- */

const EXP = new Uint8Array(512);
const LOG = new Uint8Array(256);

(function initGf() {
  let x = 1;
  for (let i = 0; i < 255; i++) {
    EXP[i] = x;
    LOG[x] = i;
    x <<= 1;
    if (x & 0x100) x ^= 0x11d; // 本原多项式 x^8 + x^4 + x^3 + x^2 + 1
  }
  for (let i = 255; i < 512; i++) EXP[i] = EXP[i - 255];
})();

function gfMul(a, b) {
  if (a === 0 || b === 0) return 0;
  return EXP[LOG[a] + LOG[b]];
}

/**
 * 生成多项式 (x - α^0)(x - α^1)...(x - α^(n-1))。
 * 返回最低位在前的系数数组 c：c[k] 是 x^k 的系数，c[n] 恒为 1。
 */
function rsGenPoly(n) {
  let c = [1];
  for (let i = 0; i < n; i++) {
    const next = new Array(c.length + 1).fill(0);
    for (let k = 0; k < c.length; k++) {
      next[k] ^= gfMul(c[k], EXP[i]);
      next[k + 1] ^= c[k];
    }
    c = next;
  }
  return c;
}

/** 计算 RS 校验码。genHi 是除最高次项外、按次数从高到低排列的系数。 */
function rsRemainder(data, genHi) {
  const n = genHi.length;
  const rem = new Array(n).fill(0); // rem[0] 为最高次
  for (const b of data) {
    const factor = b ^ rem[0];
    rem.shift();
    rem.push(0);
    if (factor !== 0) {
      for (let j = 0; j < n; j++) rem[j] ^= gfMul(genHi[j], factor);
    }
  }
  return rem;
}

/* ---------------- 版本参数表（纠错等级 M） ---------------- */

// [每块校验码数, 组1块数, 组1每块数据码数, 组2块数, 组2每块数据码数]
const ECC_M = [
  null,
  [10, 1, 16, 0, 0], // v1
  [16, 1, 28, 0, 0], // v2
  [26, 1, 44, 0, 0], // v3
  [18, 2, 32, 0, 0], // v4
  [24, 2, 43, 0, 0], // v5
  [16, 4, 27, 0, 0], // v6
  [18, 4, 31, 0, 0], // v7
  [22, 2, 38, 2, 39], // v8
  [22, 3, 36, 2, 37], // v9
  [26, 4, 43, 1, 44], // v10
];

const ALIGN = [
  null,
  [], // v1 无校正图形
  [6, 18],
  [6, 22],
  [6, 26],
  [6, 30],
  [6, 34],
  [6, 22, 38],
  [6, 24, 42],
  [6, 26, 46],
  [6, 28, 50],
];

const PENALTY_N1 = 3;
const PENALTY_N2 = 3;
const PENALTY_N3 = 40;
const PENALTY_N4 = 10;

/* ---------------- 主流程 ---------------- */

/**
 * 生成 QR 矩阵。
 * @param {string} text 要编码的文本
 * @returns {boolean[][]} 二维矩阵，true 表示深色模块
 */
export function qrMatrix(text, forceMask = -1) {
  const bytes = Array.from(new TextEncoder().encode(text));
  const version = pickVersion(bytes.length);
  if (!version) throw new Error('内容过长，超出版本 10 的容量');

  const spec = ECC_M[version];
  const ecLen = spec[0];
  const dataCapacity = spec[1] * spec[2] + spec[3] * spec[4];

  const bits = [];
  const pushBits = (value, len) => {
    for (let i = len - 1; i >= 0; i--) bits.push((value >>> i) & 1);
  };

  pushBits(0b0100, 4); // 字节模式
  pushBits(bytes.length, version < 10 ? 8 : 16);
  for (const b of bytes) pushBits(b, 8);

  const capacityBits = dataCapacity * 8;
  // 结束符 + 补齐到字节边界
  for (let i = 0; i < 4 && bits.length < capacityBits; i++) bits.push(0);
  while (bits.length % 8 !== 0) bits.push(0);

  const dataCodewords = [];
  for (let i = 0; i < bits.length; i += 8) {
    let v = 0;
    for (let j = 0; j < 8; j++) v = (v << 1) | bits[i + j];
    dataCodewords.push(v);
  }
  // 填充字节 0xEC / 0x11 交替
  for (let i = 0; dataCodewords.length < dataCapacity; i++) {
    dataCodewords.push(i % 2 === 0 ? 0xec : 0x11);
  }

  // 分块 + 计算校验码
  const blocks = [];
  let offset = 0;
  for (let g = 0; g < 2; g++) {
    const count = g === 0 ? spec[1] : spec[3];
    const len = g === 0 ? spec[2] : spec[4];
    for (let i = 0; i < count; i++) {
      const part = dataCodewords.slice(offset, offset + len);
      offset += len;
      blocks.push({ data: part, ec: rsRemainder(part, rsGenPolyHi(ecLen)) });
    }
  }

  // 交织：先是所有数据码（按块轮转），再是所有校验码
  const final = [];
  const maxData = Math.max(...blocks.map((b) => b.data.length));
  for (let i = 0; i < maxData; i++) {
    for (const b of blocks) if (i < b.data.length) final.push(b.data[i]);
  }
  for (let i = 0; i < ecLen; i++) {
    for (const b of blocks) final.push(b.ec[i]);
  }

  return buildMatrix(version, final, forceMask);
}

let genPolyCache = new Map();
function rsGenPolyHi(n) {
  if (!genPolyCache.has(n)) {
    const c = rsGenPoly(n); // 最低位在前，c[n] = 1
    const hi = [];
    for (let k = n - 1; k >= 0; k--) hi.push(c[k]); // 去掉最高次项，次数从高到低
    genPolyCache.set(n, hi);
  }
  return genPolyCache.get(n);
}

/** 选一个能装下 len 字节的最小版本 */
function pickVersion(len) {
  for (let v = 1; v <= 10; v++) {
    const countBits = v < 10 ? 8 : 16;
    const used = 4 + countBits + len * 8;
    const capacity = (ECC_M[v][1] * ECC_M[v][2] + ECC_M[v][3] * ECC_M[v][4]) * 8;
    if (used <= capacity) return v;
  }
  return 0;
}

/* ---------------- 矩阵构造 ---------------- */

function buildMatrix(version, codewords, forceMask = -1) {
  const size = version * 4 + 17;
  const modules = [];
  const isFn = [];
  for (let i = 0; i < size; i++) {
    modules.push(new Array(size).fill(false));
    isFn.push(new Array(size).fill(false));
  }

  const setFn = (x, y, dark) => {
    modules[y][x] = dark;
    isFn[y][x] = true;
  };

  // 先画定时图形，再用定位图形覆盖掉与之重合的部分（顺序不能反）
  for (let i = 0; i < size; i++) {
    setFn(6, i, i % 2 === 0);
    setFn(i, 6, i % 2 === 0);
  }

  // 定位图形（含分隔符）
  const drawFinder = (cx, cy) => {
    for (let dy = -4; dy <= 4; dy++) {
      for (let dx = -4; dx <= 4; dx++) {
        const x = cx + dx;
        const y = cy + dy;
        if (x < 0 || x >= size || y < 0 || y >= size) continue;
        const dist = Math.max(Math.abs(dx), Math.abs(dy));
        setFn(x, y, dist !== 2 && dist !== 4);
      }
    }
  };
  drawFinder(3, 3);
  drawFinder(size - 4, 3);
  drawFinder(3, size - 4);

  // 校正图形（跳过与定位图形重叠的）
  const coords = ALIGN[version] || [];
  for (let i = 0; i < coords.length; i++) {
    for (let j = 0; j < coords.length; j++) {
      const cx = coords[j];
      const cy = coords[i];
      const corner =
        (cx === 6 && cy === 6) ||
        (cx === 6 && cy === size - 7) ||
        (cx === size - 7 && cy === 6);
      if (corner) continue;
      for (let dy = -2; dy <= 2; dy++) {
        for (let dx = -2; dx <= 2; dx++) {
          setFn(cx + dx, cy + dy, Math.max(Math.abs(dx), Math.abs(dy)) !== 1);
        }
      }
    }
  }

  // 版本信息（v7 及以上）
  if (version >= 7) {
    let rem = version;
    for (let i = 0; i < 12; i++) rem = (rem << 1) ^ ((rem >>> 11) * 0x1f25);
    const bits = (version << 12) | rem;
    for (let i = 0; i < 18; i++) {
      const bit = ((bits >>> i) & 1) !== 0;
      const a = size - 11 + (i % 3);
      const b = Math.floor(i / 3);
      setFn(a, b, bit);
      setFn(b, a, bit);
    }
  }

  // 预留格式信息区域（真正的值在选定掩码后写入）
  // 注意 (6,8) 和 (8,6) 属于定时图形，不能动
  for (let i = 0; i <= 8; i++) if (i !== 6) setFn(8, i, false);
  for (let i = 0; i < 8; i++) if (i !== 6) setFn(i, 8, false);
  for (let i = 0; i < 8; i++) setFn(size - 1 - i, 8, false);
  for (let i = 8; i < 15; i++) setFn(8, size - 15 + i, false);
  setFn(8, size - 8, true); // 固定深色模块，必须在放数据之前就占住

  // 放置数据位（之字形，跳过功能图形）
  let bitIndex = 0;
  const total = codewords.length * 8;
  for (let right = size - 1; right >= 1; right -= 2) {
    if (right === 6) right = 5;
    for (let vert = 0; vert < size; vert++) {
      for (let j = 0; j < 2; j++) {
        const x = right - j;
        const upward = ((right + 1) & 2) === 0;
        const y = upward ? size - 1 - vert : vert;
        if (!isFn[y][x] && bitIndex < total) {
          const byte = codewords[bitIndex >>> 3];
          modules[y][x] = ((byte >>> (7 - (bitIndex & 7))) & 1) !== 0;
          bitIndex++;
        }
      }
    }
  }

  // 逐个掩码算惩罚分，取最优
  const applyMask = (mask) => {
    for (let y = 0; y < size; y++) {
      for (let x = 0; x < size; x++) {
        let invert = false;
        switch (mask) {
          case 0: invert = (x + y) % 2 === 0; break;
          case 1: invert = y % 2 === 0; break;
          case 2: invert = x % 3 === 0; break;
          case 3: invert = (x + y) % 3 === 0; break;
          case 4: invert = (Math.floor(x / 3) + Math.floor(y / 2)) % 2 === 0; break;
          case 5: invert = ((x * y) % 2) + ((x * y) % 3) === 0; break;
          case 6: invert = (((x * y) % 2) + ((x * y) % 3)) % 2 === 0; break;
          case 7: invert = (((x + y) % 2) + ((x * y) % 3)) % 2 === 0; break;
          default: break;
        }
        if (!isFn[y][x] && invert) modules[y][x] = !modules[y][x];
      }
    }
  };

  if (forceMask >= 0 && forceMask < 8) {
    applyMask(forceMask);
    drawFormatBits(modules, setFn, size, forceMask);
    return { matrix: modules, isFn, size, version, mask: forceMask, placedBits: bitIndex, codewords };
  }

  let bestMask = 0;
  let bestScore = Infinity;
  for (let mask = 0; mask < 8; mask++) {
    applyMask(mask);
    drawFormatBits(modules, setFn, size, mask);
    const score = penaltyScore(modules, size);
    applyMask(mask); // XOR 两次即还原
    if (score < bestScore) {
      bestScore = score;
      bestMask = mask;
    }
  }
  applyMask(bestMask);
  drawFormatBits(modules, setFn, size, bestMask);

  return { matrix: modules, isFn, size, version, mask: bestMask, placedBits: bitIndex, codewords };
}

/** 写入 15 位格式信息（纠错等级 M = 00） */
function drawFormatBits(modules, setFn, size, mask) {
  const data = (0b00 << 3) | mask;
  let rem = data;
  for (let i = 0; i < 10; i++) rem = (rem << 1) ^ ((rem >>> 9) * 0x537);
  const bits = ((data << 10) | rem) ^ 0x5412;

  for (let i = 0; i <= 5; i++) setFn(8, i, ((bits >>> i) & 1) !== 0);
  setFn(8, 7, ((bits >>> 6) & 1) !== 0);
  setFn(8, 8, ((bits >>> 7) & 1) !== 0);
  setFn(7, 8, ((bits >>> 8) & 1) !== 0);
  for (let i = 9; i < 15; i++) setFn(14 - i, 8, ((bits >>> i) & 1) !== 0);

  for (let i = 0; i < 8; i++) setFn(size - 1 - i, 8, ((bits >>> i) & 1) !== 0);
  for (let i = 8; i < 15; i++) setFn(8, size - 15 + i, ((bits >>> i) & 1) !== 0);
  setFn(8, size - 8, true); // 固定深色模块
}

/* ---------------- 惩罚分 ---------------- */

function penaltyScore(modules, size) {
  let result = 0;

  const addHistory = (run, hist) => {
    if (hist[0] === 0) run += size; // 起始处补上白色边框
    hist.pop();
    hist.unshift(run);
  };
  const countPatterns = (hist) => {
    const n = hist[1];
    const core = n > 0 && hist[2] === n && hist[3] === n * 3 && hist[4] === n && hist[5] === n;
    return (
      (core && hist[0] >= n * 4 && hist[6] >= n ? 1 : 0) +
      (core && hist[6] >= n * 4 && hist[0] >= n ? 1 : 0)
    );
  };

  // 行方向
  for (let y = 0; y < size; y++) {
    let runColor = false;
    let runLen = 0;
    const hist = new Array(7).fill(0);
    for (let x = 0; x < size; x++) {
      if (modules[y][x] === runColor) {
        runLen++;
        if (runLen === 5) result += PENALTY_N1;
        else if (runLen > 5) result++;
      } else {
        addHistory(runLen, hist);
        if (!runColor) result += countPatterns(hist) * PENALTY_N3;
        runColor = modules[y][x];
        runLen = 1;
      }
    }
    if (runColor) {
      addHistory(runLen, hist);
      runLen = 0;
    }
    addHistory(runLen + size, hist);
    result += countPatterns(hist) * PENALTY_N3;
  }

  // 列方向
  for (let x = 0; x < size; x++) {
    let runColor = false;
    let runLen = 0;
    const hist = new Array(7).fill(0);
    for (let y = 0; y < size; y++) {
      if (modules[y][x] === runColor) {
        runLen++;
        if (runLen === 5) result += PENALTY_N1;
        else if (runLen > 5) result++;
      } else {
        addHistory(runLen, hist);
        if (!runColor) result += countPatterns(hist) * PENALTY_N3;
        runColor = modules[y][x];
        runLen = 1;
      }
    }
    if (runColor) {
      addHistory(runLen, hist);
      runLen = 0;
    }
    addHistory(runLen + size, hist);
    result += countPatterns(hist) * PENALTY_N3;
  }

  // 2x2 同色块
  for (let y = 0; y < size - 1; y++) {
    for (let x = 0; x < size - 1; x++) {
      const c = modules[y][x];
      if (c === modules[y][x + 1] && c === modules[y + 1][x] && c === modules[y + 1][x + 1]) {
        result += PENALTY_N2;
      }
    }
  }

  // 深色占比偏离 50% 的惩罚
  let dark = 0;
  for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) if (modules[y][x]) dark++;
  const total = size * size;
  const k = Math.ceil(Math.abs(dark * 20 - total * 10) / total) - 1;
  result += k * PENALTY_N4;

  return result;
}

/** 把矩阵画到 canvas 上（含 4 模块静区），返回是否成功 */
export function drawQr(canvas, text, { minScale = 3, maxPx = 168 } = {}) {
  let out;
  try {
    out = qrMatrix(text);
  } catch {
    return false;
  }
  const m = out.matrix;
  const n = m.length;
  const quiet = 4;
  const total = n + quiet * 2;
  const scale = Math.max(minScale, Math.floor(maxPx / total));
  const cssPx = total * scale;
  const dpr = (typeof window !== 'undefined' && window.devicePixelRatio) || 1;

  canvas.width = Math.round(cssPx * dpr);
  canvas.height = Math.round(cssPx * dpr);
  canvas.style.width = `${cssPx}px`;
  canvas.style.height = `${cssPx}px`;

  const ctx = canvas.getContext('2d');
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, cssPx, cssPx);
  ctx.fillStyle = '#000000';
  for (let y = 0; y < n; y++) {
    for (let x = 0; x < n; x++) {
      if (m[y][x]) ctx.fillRect((x + quiet) * scale, (y + quiet) * scale, scale, scale);
    }
  }
  return true;
}
