import { randomId } from './util.js';

/**
 * 会话与传输引擎。
 * 文字消息：DataChannel 直发；P2P 未就绪时用服务器兜底中转（仅文字）。
 * 文件：DataChannel 分片直传，带背压控制、进度、速度与接收确认。
 */

const CHUNK = 64 * 1024;            // P2P 每片 64KB
const LOW_WATER = 512 * 1024;       // DataChannel 发送缓冲低水位
const RELAY_CHUNK = 96 * 1024;      // 兜底中转每片 96KB（base64 后约 128KB）
const RELAY_HIGH_WATER = 2 * 1024 * 1024;
const HISTORY_LIMIT = 300;
const WAIT_OPEN_TIMEOUT = 15_000;

function abToBase64(buffer) {
  const bytes = new Uint8Array(buffer);
  let str = '';
  const step = 0x8000;
  for (let i = 0; i < bytes.length; i += step) {
    str += String.fromCharCode.apply(null, bytes.subarray(i, i + step));
  }
  return btoa(str);
}

function base64ToAb(b64) {
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out.buffer;
}

export class Chat {
  constructor({ peers, signal }) {
    this.peers = peers;
    this.signal = signal;
    this.userId = 'anon';
    this.byPeer = new Map();     // peerId -> msg[]
    this.byId = new Map();       // msgId -> msg
    this.incoming = new Map();   // peerId -> 正在接收的文件
    this.queues = new Map();     // peerId -> 发送队列
    this.onAdd = () => {};
    this.onUpdate = () => {};
    this.saveTimers = new Map();
  }

  setUser(userId) {
    this.userId = userId || 'anon';
    this.byPeer.clear();
    this.byId.clear();
  }

  /* ------------------------- 历史记录 ------------------------- */

  _key(peerId) {
    return `lanlinker.hist.${this.userId}.${peerId}`;
  }

  list(peerId) {
    if (!this.byPeer.has(peerId)) {
      let arr = [];
      try {
        const raw = localStorage.getItem(this._key(peerId));
        if (raw) {
          arr = JSON.parse(raw).map((m) => ({
            ...m,
            expired: m.kind === 'file',
            url: null,
          }));
        }
      } catch {
        arr = [];
      }
      for (const m of arr) this.byId.set(m.id, m);
      this.byPeer.set(peerId, arr);
    }
    return this.byPeer.get(peerId);
  }

  _save(peerId) {
    if (this.saveTimers.has(peerId)) return;
    this.saveTimers.set(
      peerId,
      setTimeout(() => {
        this.saveTimers.delete(peerId);
        try {
          const list = (this.byPeer.get(peerId) || [])
            .filter((m) => m.kind !== 'system')
            .slice(-HISTORY_LIMIT)
            .map((m) => ({
              id: m.id, peer: m.peer, dir: m.dir, kind: m.kind, text: m.text,
              name: m.name, size: m.size, mime: m.mime, ts: m.ts,
              status: m.kind === 'file'
                ? (m.status === 'done' || m.status === 'sent' ? m.status : 'failed')
                : m.status,
              via: m.via,
            }));
          localStorage.setItem(this._key(peerId), JSON.stringify(list));
        } catch {
          /* 配额不足等情况忽略 */
        }
      }, 400)
    );
  }

  clearHistory(peerId) {
    this.byPeer.set(peerId, []);
    try {
      localStorage.removeItem(this._key(peerId));
    } catch { /* ignore */ }
  }

  /* ------------------------- 消息基础 ------------------------- */

  _add(msg) {
    const list = this.list(msg.peer);
    list.push(msg);
    if (list.length > HISTORY_LIMIT + 50) list.splice(0, list.length - HISTORY_LIMIT);
    this.byId.set(msg.id, msg);
    this.onAdd(msg);
    this._save(msg.peer);
    return msg;
  }

  _update(msg, patch = {}) {
    Object.assign(msg, patch);
    this.onUpdate(msg);
    if (patch.status) this._save(msg.peer);
  }

  system(peerId, text) {
    return this._add({
      id: randomId(6), peer: peerId, dir: 'sys', kind: 'system', text, ts: Date.now(), status: 'done',
    });
  }

  /* ------------------------- 发送文字 ------------------------- */

  sendText(peerId, text) {
    const msg = {
      id: randomId(8), peer: peerId, dir: 'out', kind: 'text',
      text, ts: Date.now(), status: 'done',
    };
    const payload = { k: 'text', id: msg.id, text, ts: msg.ts };

    if (this.peers.isOpen(peerId)) {
      this.peers.send(peerId, JSON.stringify(payload));
    } else {
      const ok = this.signal.send({ t: 'relay', to: peerId, payload });
      msg.via = 'server';
      if (!ok) {
        msg.status = 'failed';
        msg.error = '发送失败：与服务器的连接已断开';
      }
      // 顺手尝试建立 P2P，后续文件传输才能进行
      this.peers.ensure(peerId);
    }
    return this._add(msg);
  }

  /* ------------------------- 发送文件 ------------------------- */

  sendFiles(peerId, files) {
    const list = Array.from(files || []);
    if (!list.length) return [];
    this.peers.ensure(peerId);
    // 超大文件提醒：接收端目前要在内存里拼装 Blob，超过约 1.5GB 可能失败
    if (list.some((f) => f.size > 1.5 * 1024 * 1024 * 1024)) {
      this.system(peerId, '提示：有超过 1.5GB 的大文件，接收方设备内存不足时可能接收失败，建议先测试小文件。');
    }
    const msgs = list.map((file) => {
      const msg = {
        id: randomId(8), peer: peerId, dir: 'out', kind: 'file',
        name: file.name || '未命名文件', size: file.size, mime: file.type || '',
        sent: 0, status: 'queued', ts: Date.now(),
      };
      if (file.type && file.type.startsWith('image/') && file.size <= 12 * 1024 * 1024) {
        try {
          msg.preview = URL.createObjectURL(file);
        } catch { /* ignore */ }
      }
      this._add(msg);
      this._enqueue(peerId, () => this._sendFile(msg, file));
      return msg;
    });
    return msgs;
  }

  _enqueue(peerId, task) {
    const prev = this.queues.get(peerId) || Promise.resolve();
    const next = prev.then(task).catch((err) => console.error('[send queue]', err));
    this.queues.set(peerId, next);
    return next;
  }

  async _waitOpen(peerId, msg) {
    const started = Date.now();
    while (Date.now() - started < WAIT_OPEN_TIMEOUT) {
      if (this.peers.isOpen(peerId)) return true;
      if (msg && msg.cancelRequested) return false;
      const state = this.peers.stateOf(peerId);
      if (state === 'failed' || state === 'closed' || state === 'new') this.peers.ensure(peerId);
      await new Promise((r) => setTimeout(r, 250));
    }
    return this.peers.isOpen(peerId);
  }

  async _sendFile(msg, file) {
    if (msg.status === 'canceled' || msg.cancelRequested) return;
    this._update(msg, { status: 'connecting' });

    const ok = await this._waitOpen(msg.peer, msg);
    if (msg.cancelRequested) {
      this._update(msg, { status: 'canceled', error: '已取消发送' });
      return;
    }

    const link = ok ? this.peers.get(msg.peer) : null;
    const dc = link && link.dc;
    if (!ok || !dc) {
      // 打洞失败时退回服务器中转，保证文件仍然能送到
      if (this.signal.connected) {
        this.system(msg.peer, '点对点连接未能建立，已自动切换为服务器中转（速度较慢）');
        await this._sendFileViaRelay(msg, file);
      } else {
        this._update(msg, { status: 'failed', error: '连接不可用，文件无法发送' });
      }
      return;
    }

    try {
      dc.send(JSON.stringify({
        k: 'file-meta', id: msg.id, name: msg.name, size: msg.size, mime: msg.mime,
      }));
    } catch (err) {
      this._update(msg, { status: 'failed', error: '发送失败：' + err.message });
      return;
    }

    this._update(msg, { status: 'sending', sent: 0, startedAt: Date.now() });

    let offset = 0;
    let tickBytes = 0;
    let tickAt = Date.now();

    try {
      while (offset < file.size) {
        if (msg.cancelRequested) throw Object.assign(new Error('已取消'), { canceled: true });
        if (dc.readyState !== 'open') throw new Error('连接已断开');

        // 背压：缓冲区太满时等它排空一些，避免爆内存
        while (dc.readyState === 'open' && dc.bufferedAmount > LOW_WATER) {
          await new Promise((r) => setTimeout(r, 15));
          if (msg.cancelRequested) throw Object.assign(new Error('已取消'), { canceled: true });
        }
        if (dc.readyState !== 'open') throw new Error('连接已断开');

        const slice = file.slice(offset, Math.min(offset + CHUNK, file.size));
        const buf = await slice.arrayBuffer();
        dc.send(buf);
        offset += buf.byteLength;
        tickBytes += buf.byteLength;

        const now = Date.now();
        if (now - tickAt >= 120 || offset >= file.size) {
          const speed = tickBytes / Math.max(1, (now - tickAt)) * 1000;
          tickAt = now;
          tickBytes = 0;
          this._update(msg, { sent: offset, speed });
        }
      }

      dc.send(JSON.stringify({ k: 'file-end', id: msg.id }));
      this._update(msg, { sent: file.size, status: 'sent', speed: 0 });
    } catch (err) {
      const canceled = err.canceled || msg.cancelRequested;
      try {
        if (dc.readyState === 'open') dc.send(JSON.stringify({ k: 'file-cancel', id: msg.id }));
      } catch { /* ignore */ }
      this._update(msg, {
        status: canceled ? 'canceled' : 'failed',
        speed: 0,
        error: canceled ? '已取消发送' : `传输中断：${err.message}`,
      });
    }
  }

  /** P2P 不可用时的兜底：通过服务器以 base64 分片中转 */
  async _sendFileViaRelay(msg, file) {
    const relay = (payload) => this.signal.send({ t: 'relay', to: msg.peer, payload });

    if (!relay({ k: 'file-meta', id: msg.id, name: msg.name, size: msg.size, mime: msg.mime, via: 'server' })) {
      this._update(msg, { status: 'failed', error: '服务器连接已断开' });
      return;
    }
    this._update(msg, { status: 'sending', via: 'server', sent: 0, startedAt: Date.now() });

    let offset = 0;
    let seq = 0;
    let tickBytes = 0;
    let tickAt = Date.now();

    try {
      while (offset < file.size) {
        if (msg.cancelRequested) throw Object.assign(new Error('已取消'), { canceled: true });
        if (!this.signal.connected) throw new Error('服务器连接已断开');

        while (this.signal.connected && this.signal.bufferedAmount > RELAY_HIGH_WATER) {
          await new Promise((r) => setTimeout(r, 20));
          if (msg.cancelRequested) throw Object.assign(new Error('已取消'), { canceled: true });
        }

        const slice = file.slice(offset, Math.min(offset + RELAY_CHUNK, file.size));
        const buf = await slice.arrayBuffer();
        if (!relay({ k: 'file-chunk', id: msg.id, seq: seq++, data: abToBase64(buf) })) {
          throw new Error('服务器连接已断开');
        }
        offset += buf.byteLength;
        tickBytes += buf.byteLength;

        const now = Date.now();
        if (now - tickAt >= 150 || offset >= file.size) {
          const speed = tickBytes / Math.max(1, now - tickAt) * 1000;
          tickAt = now;
          tickBytes = 0;
          this._update(msg, { sent: offset, speed });
        }
      }
      relay({ k: 'file-end', id: msg.id });
      this._update(msg, { sent: file.size, status: 'sent', speed: 0 });
    } catch (err) {
      const canceled = err.canceled || msg.cancelRequested;
      relay({ k: 'file-cancel', id: msg.id });
      this._update(msg, {
        status: canceled ? 'canceled' : 'failed',
        speed: 0,
        error: canceled ? '已取消发送' : `中转失败：${err.message}`,
      });
    }
  }

  cancel(msgId) {
    const msg = this.byId.get(msgId);
    if (!msg) return;
    msg.cancelRequested = true;
    if (msg.dir === 'out' && (msg.status === 'queued' || msg.status === 'connecting')) {
      this._update(msg, { status: 'canceled', error: '已取消发送' });
    }
  }

  /* ------------------------- 接收 ------------------------- */

  /** 服务器中转过来的消息（文字或 base64 文件分片） */
  handleRelay(peerId, payload) {
    if (!payload || !payload.k) return;
    if (payload.k === 'file-chunk') {
      try {
        this._handleChunk(peerId, base64ToAb(payload.data));
      } catch (err) {
        console.warn('[relay chunk]', err.message);
      }
      return;
    }
    this._handleControl(peerId, payload, 'server');
  }

  handleData(peerId, data) {
    if (typeof data === 'string') {
      let msg;
      try {
        msg = JSON.parse(data);
      } catch {
        return;
      }
      this._handleControl(peerId, msg);
      return;
    }
    if (data instanceof ArrayBuffer) {
      this._handleChunk(peerId, data);
      return;
    }
    if (typeof Blob !== 'undefined' && data instanceof Blob) {
      data.arrayBuffer().then((buf) => this._handleChunk(peerId, buf));
    }
  }

  _handleControl(peerId, msg, via) {
    if (!msg || !msg.k) return;

    switch (msg.k) {
      case 'text':
        this._add({
          id: msg.id || randomId(8), peer: peerId, dir: 'in', kind: 'text',
          text: String(msg.text || ''), ts: msg.ts || Date.now(), status: 'done', via,
        });
        return;

      case 'file-meta': {
        const record = {
          id: msg.id || randomId(8), peer: peerId, dir: 'in', kind: 'file',
          name: msg.name || '未命名文件', size: Number(msg.size) || 0, mime: msg.mime || '',
          received: 0, status: 'receiving', ts: Date.now(), via,
        };
        this._add(record);
        this.incoming.set(peerId, {
          msg: record, parts: [], received: 0, tickAt: Date.now(), tickBytes: 0,
        });
        return;
      }

      case 'file-end': {
        const cur = this.incoming.get(peerId);
        if (!cur) return;
        this.incoming.delete(peerId);
        const blob = new Blob(cur.parts, { type: cur.msg.mime || 'application/octet-stream' });
        cur.parts = [];
        let url = null;
        try {
          url = URL.createObjectURL(blob);
        } catch { /* ignore */ }
        const patch = { status: 'done', url, received: blob.size, speed: 0 };
        if ((cur.msg.mime || '').startsWith('image/') && blob.size <= 12 * 1024 * 1024) patch.preview = url;
        this._update(cur.msg, patch);
        this._reply(peerId, { k: 'file-ack', id: cur.msg.id });
        return;
      }

      case 'file-ack': {
        const target = this.byId.get(msg.id);
        if (target && target.dir === 'out') this._update(target, { status: 'done' });
        return;
      }

      case 'file-cancel': {
        const cur = this.incoming.get(peerId);
        if (cur && (!msg.id || cur.msg.id === msg.id)) {
          this.incoming.delete(peerId);
          cur.parts = [];
          this._update(cur.msg, { status: 'failed', error: '对方中断了传输' });
          return;
        }
        const target = this.byId.get(msg.id);
        if (target) this._update(target, { status: 'failed', error: '传输被中断' });
        return;
      }

      default:
        return;
    }
  }

  /** 回执优先走 P2P，没有就走服务器 */
  _reply(peerId, payload) {
    if (this.peers.isOpen(peerId)) {
      this.peers.send(peerId, JSON.stringify(payload));
      return;
    }
    this.signal.send({ t: 'relay', to: peerId, payload });
  }

  _handleChunk(peerId, buf) {
    const cur = this.incoming.get(peerId);
    if (!cur) return;
    cur.parts.push(buf);
    cur.received += buf.byteLength;
    cur.tickBytes += buf.byteLength;

    const now = Date.now();
    if (now - cur.tickAt >= 120 || cur.received >= cur.msg.size) {
      const speed = cur.tickBytes / Math.max(1, now - cur.tickAt) * 1000;
      cur.tickAt = now;
      cur.tickBytes = 0;
      this._update(cur.msg, { received: cur.received, speed });
    }
  }

  /** 对方掉线：把正在进行的传输标记为失败 */
  peerGone(peerId) {
    const cur = this.incoming.get(peerId);
    if (cur) {
      this.incoming.delete(peerId);
      cur.parts = [];
      this._update(cur.msg, { status: 'failed', error: '对方已离线，接收中断' });
    }
    for (const msg of this.list(peerId)) {
      if (msg.dir === 'out' && (msg.status === 'sending' || msg.status === 'connecting' || msg.status === 'queued')) {
        msg.cancelRequested = true;
        this._update(msg, { status: 'failed', error: '对方已离线', speed: 0 });
      }
    }
  }
}
