import { $, fmtBytes, fmtSpeed, fmtClock, fmtDay, fmtLastSeen, renderText, escapeHtml, extLabel, copyText } from './util.js';
import { drawQr } from './qr.js';

const el = {};
let lastDayKey = '';
const msgEls = new Map();

export function initDom() {
  Object.assign(el, {
    viewAuth: $('#view-auth'),
    viewApp: $('#view-app'),
    toastWrap: $('#toast-wrap'),

    authTabs: $('#auth-tabs'),
    authForm: $('#auth-form'),
    username: $('#auth-username'),
    password: $('#auth-password'),
    confirm: $('#auth-confirm'),
    confirmField: $('#auth-confirm-field'),
    remember: $('#auth-remember'),
    agree: $('#auth-agree'),
    agreeField: $('#auth-agree-field'),
    authError: $('#auth-error'),
    authSubmit: $('#auth-submit'),
    registerClosedTip: $('#register-closed-tip'),

    accName: $('#acc-name'),
    accLan: $('#acc-lan'),
    selfName: $('#self-name'),
    selfMeta: $('#self-meta'),
    btnRename: $('#btn-rename'),
    btnLogout: $('#btn-logout'),
    wsState: $('#ws-state'),
    devCount: $('#dev-count'),
    deviceList: $('#device-list'),

    chatEmpty: $('#chat-empty'),
    chatInner: $('#chat-inner'),
    peerName: $('#peer-name'),
    peerMeta: $('#peer-meta'),
    connBadge: $('#conn-badge'),
    btnReconnect: $('#btn-reconnect'),
    btnBack: $('#btn-back'),
    messages: $('#messages'),
    composer: $('#composer'),
    inputText: $('#input-text'),
    btnSend: $('#btn-send'),
    btnFile: $('#btn-file'),
    fileInput: $('#file-input'),
    dropMask: $('#drop-mask'),

    addrRow: $('#addr-row'),
    lanAddr: $('#lan-addr'),
    btnCopyAddr: $('#btn-copy-addr'),
    qrWrap: $('#qr-wrap'),
    qrCanvas: $('#qr-canvas'),
    btnQr: $('#btn-qr'),
  });
  return el;
}

export const dom = el;

/* ---------------------------- 通用 ---------------------------- */

export function toast(text, type = '') {
  const node = document.createElement('div');
  node.className = `toast ${type}`;
  node.textContent = text;
  el.toastWrap.appendChild(node);
  setTimeout(() => {
    node.style.transition = 'opacity .25s';
    node.style.opacity = '0';
    setTimeout(() => node.remove(), 260);
  }, 2600);
}

export function showAuth() {
  el.viewAuth.hidden = false;
  el.viewApp.hidden = true;
}

export function showApp() {
  el.viewAuth.hidden = true;
  el.viewApp.hidden = false;
}

export function setAuthMode(mode) {
  for (const tab of el.authTabs.querySelectorAll('.tab')) {
    tab.classList.toggle('is-active', tab.dataset.mode === mode);
  }
  const isRegister = mode === 'register';
  el.confirmField.hidden = !isRegister;
  el.agreeField.hidden = !isRegister;
  if (!isRegister && el.agree) el.agree.checked = false;
  el.authSubmit.textContent = isRegister ? '注册并登录' : '登录';
  el.password.autocomplete = isRegister ? 'new-password' : 'current-password';
  setAuthError('');
}

export function setAuthError(text) {
  el.authError.textContent = text || '';
  el.authError.hidden = !text;
}

export function setAuthBusy(busy, mode) {
  el.authSubmit.disabled = busy;
  el.authSubmit.textContent = busy ? '请稍候…' : mode === 'register' ? '注册并登录' : '登录';
}

/**
 * 根据服务端是否开放注册，调整登录页：
 * 关闭时隐藏「注册」标签、强制回登录模式，并提示用户。
 */
export function setRegisterOpen(open) {
  if (el.registerClosedTip) el.registerClosedTip.hidden = open;
  const regTab = el.authTabs && el.authTabs.querySelector('.tab[data-mode="register"]');
  if (regTab) regTab.hidden = !open;
  if (!open) setAuthMode('login');
}

/* ---------------------------- 侧栏 ---------------------------- */

export function setAccount({ username, lanId }) {
  el.accName.textContent = username || '—';
  el.accLan.textContent = lanId ? `局域网 ${lanId}` : '—';
}

export function setSelf({ name, platform, ip }) {
  el.selfName.textContent = name || '本机';
  el.selfMeta.textContent = [platform, ip].filter(Boolean).join(' · ') || '—';
}

export function setWsState(ok, text) {
  el.wsState.textContent = text;
  el.wsState.dataset.ok = ok ? '1' : '0';
}

/**
 * 显示本机的局域网访问地址。IP 变了也不会认错，因为地址是服务端实时报上来的。
 * 没有局域网地址（比如服务只监听在本机）时隐藏整行。
 */
export function setLanAddress(url) {
  if (!el.addrRow) return;
  if (!url) {
    el.addrRow.hidden = true;
    el.qrWrap.hidden = true;
    return;
  }
  el.addrRow.hidden = false;
  el.lanAddr.textContent = url;
  el.lanAddr.title = url;
}

/** 显示/隐藏地址对应的二维码，返回切换后的可见状态 */
export function toggleQr(url) {
  if (!el.qrWrap) return false;
  if (!el.qrWrap.hidden) {
    el.qrWrap.hidden = true;
    return false;
  }
  if (!url || url === '—') return false;
  const ok = drawQr(el.qrCanvas, url, { maxPx: 156 });
  if (!ok) return false;
  el.qrWrap.hidden = false;
  return true;
}

/** 地址变了就关掉二维码，避免扫到旧地址 */
export function hideQr() {
  if (el.qrWrap) el.qrWrap.hidden = true;
}

const CONN_TEXT = {
  new: '未连接',
  connecting: '连接中…',
  connected: '点对点已连接',
  failed: '连接失败',
  closed: '连接已断开',
};

export function renderDevices(devices, { activeId, unread, stateOf }) {
  const others = devices.filter((d) => !d.self);
  const online = others.filter((d) => d.online).length;
  el.devCount.textContent = others.length ? `（在线 ${online}/${others.length}）` : '';

  el.deviceList.innerHTML = '';
  if (!others.length) {
    const li = document.createElement('li');
    li.className = 'device-empty';
    li.innerHTML = '还没有其它设备<br />在同一局域网的另一台设备上<br />用<b>相同账号</b>登录本页面即可自动出现';
    el.deviceList.appendChild(li);
    return;
  }

  for (const device of others) {
    const li = document.createElement('li');
    li.className = 'device';
    li.dataset.id = device.id;
    if (device.id === activeId) li.classList.add('is-active');
    if (!device.online) li.classList.add('is-offline');

    const state = stateOf(device.id);
    const badges = [];
    if (device.online) {
      badges.push(device.sameLan
        ? '<span class="tag lan">同一局域网</span>'
        : '<span class="tag other-lan">不同网段</span>');
    }
    if (device.online && state && state !== 'new') {
      badges.push(`<span class="badge">${escapeHtml(CONN_TEXT[state] || state)}</span>`);
    }
    if (!device.online) badges.push(`<span class="badge">${escapeHtml(fmtLastSeen(device.lastSeen))}</span>`);

    const count = unread.get(device.id) || 0;
    li.innerHTML = `
      <span class="dot ${device.online ? 'online' : ''}"></span>
      <div class="grow">
        <div class="name">${escapeHtml(device.name)}</div>
        <div class="sub">${badges.join('')}</div>
      </div>
      ${count ? `<span class="unread">${count > 99 ? '99+' : count}</span>` : ''}
      ${device.online ? '' : '<button class="link-btn" data-act="forget" title="解除绑定">解绑</button>'}
    `;
    el.deviceList.appendChild(li);
  }
}

/* ---------------------------- 会话 ---------------------------- */

export function openChatView(device, { mobile = false } = {}) {
  el.chatEmpty.hidden = true;
  el.chatInner.hidden = false;
  el.peerName.textContent = device.name;
  el.peerMeta.textContent = [
    device.platform,
    device.online ? (device.sameLan ? '同一局域网' : '不同网段') : '离线',
    device.ip || '',
  ].filter(Boolean).join(' · ');
  if (mobile) el.viewApp.classList.add('show-chat');
}

export function closeChatView() {
  el.viewApp.classList.remove('show-chat');
}

export function setConnBadge(state) {
  el.connBadge.dataset.state = state;
  el.connBadge.textContent = CONN_TEXT[state] || state;
}

function nearBottom() {
  const m = el.messages;
  return m.scrollHeight - m.scrollTop - m.clientHeight < 140;
}

function scrollToBottom() {
  el.messages.scrollTop = el.messages.scrollHeight;
}

export function renderMessages(list) {
  el.messages.innerHTML = '';
  msgEls.clear();
  lastDayKey = '';
  for (const msg of list) appendMessage(msg, { silent: true });
  requestAnimationFrame(scrollToBottom);
}

export function appendMessage(msg, { silent = false } = {}) {
  const dayKey = new Date(msg.ts).toDateString();
  if (dayKey !== lastDayKey) {
    lastDayKey = dayKey;
    const sep = document.createElement('div');
    sep.className = 'day-sep';
    sep.textContent = fmtDay(msg.ts);
    el.messages.appendChild(sep);
  }

  const stick = silent || nearBottom() || msg.dir === 'out';
  const node = buildMessage(msg);
  msgEls.set(msg.id, node);
  el.messages.appendChild(node);
  if (stick) requestAnimationFrame(scrollToBottom);
}

export function updateMessage(msg) {
  const node = msgEls.get(msg.id);
  if (!node) return;
  const stick = nearBottom();
  const next = buildMessage(msg);
  node.replaceWith(next);
  msgEls.set(msg.id, next);
  if (stick) requestAnimationFrame(scrollToBottom);
}

function statusLine(msg) {
  const size = fmtBytes(msg.size);
  const speed = msg.speed ? ` · ${fmtSpeed(msg.speed)}` : '';
  if (msg.expired) return `${size} · 历史记录，文件已失效`;

  if (msg.dir === 'out') {
    switch (msg.status) {
      case 'queued': return `${size} · 排队中`;
      case 'connecting': return `${size} · 正在建立点对点连接…`;
      case 'sending': {
        const pct = msg.size ? Math.floor((msg.sent || 0) / msg.size * 100) : 0;
        return `${size} · 已发送 ${pct}%${speed}`;
      }
      case 'sent': return `${size} · 已发送，等待对方确认`;
      case 'done': return `${size} · <span class="state-done">对方已接收 ✓</span>`;
      case 'canceled': return `${size} · 已取消`;
      case 'failed': return `${size} · <span class="state-failed">${escapeHtml(msg.error || '发送失败')}</span>`;
      default: return size;
    }
  }
  switch (msg.status) {
    case 'receiving': {
      const pct = msg.size ? Math.floor((msg.received || 0) / msg.size * 100) : 0;
      return `${size} · 接收中 ${pct}%${speed}`;
    }
    case 'done': return `${size} · <span class="state-done">接收完成</span>`;
    case 'failed': return `${size} · <span class="state-failed">${escapeHtml(msg.error || '接收失败')}</span>`;
    default: return size;
  }
}

function buildMessage(msg) {
  if (msg.kind === 'system') {
    const div = document.createElement('div');
    div.className = 'sys-msg';
    div.textContent = msg.text;
    return div;
  }

  const wrap = document.createElement('div');
  wrap.className = `msg ${msg.dir === 'out' ? 'out' : 'in'}`;
  wrap.dataset.id = msg.id;

  if (msg.kind === 'text') {
    const bubble = document.createElement('div');
    bubble.className = 'bubble';
    bubble.innerHTML = renderText(msg.text);

    if (msg.dir === 'in' && !msg.expired) {
      const copy = document.createElement('button');
      copy.className = 'copy-btn';
      copy.type = 'button';
      copy.dataset.act = 'copy';
      copy.dataset.id = msg.id;
      copy.textContent = '复制';
      copy.addEventListener('click', async () => {
        const ok = await copyText(msg.text);
        copy.textContent = ok ? '已复制 ✓' : '复制失败';
        setTimeout(() => { copy.textContent = '复制'; }, 1400);
      });
      bubble.appendChild(copy);
    }
    wrap.appendChild(bubble);
  } else {
    const card = document.createElement('div');
    card.className = 'file-card';

    const inFlight = msg.status === 'sending' || msg.status === 'receiving';
    const pct = msg.size
      ? Math.min(100, Math.floor(((msg.dir === 'out' ? msg.sent : msg.received) || 0) / msg.size * 100))
      : 0;

    const icon = msg.preview
      ? `<div class="file-icon"><img src="${msg.preview}" alt="" /></div>`
      : `<div class="file-icon">${escapeHtml(extLabel(msg.name))}</div>`;

    card.innerHTML = `
      <div class="file-top">
        ${icon}
        <div class="grow">
          <div class="file-name" title="${escapeHtml(msg.name)}">${escapeHtml(msg.name)}</div>
          <div class="file-sub">${statusLine(msg)}</div>
        </div>
      </div>
      ${inFlight ? `<div class="progress"><i style="width:${pct}%"></i></div>` : ''}
      <div class="file-actions"></div>
    `;

    const actions = card.querySelector('.file-actions');
    if (inFlight || msg.status === 'queued' || msg.status === 'connecting') {
      const btn = document.createElement('button');
      btn.className = 'mini-btn';
      btn.dataset.act = 'cancel';
      btn.dataset.id = msg.id;
      btn.textContent = '取消';
      actions.appendChild(btn);
    }
    if (msg.dir === 'in' && msg.status === 'done' && msg.url) {
      const a = document.createElement('a');
      a.className = 'mini-btn primary';
      a.href = msg.url;
      a.download = msg.name;
      a.textContent = '保存到本机';
      actions.appendChild(a);
      if (msg.preview) {
        const view = document.createElement('a');
        view.className = 'mini-btn';
        view.href = msg.url;
        view.target = '_blank';
        view.rel = 'noreferrer';
        view.textContent = '预览';
        actions.appendChild(view);
      }
    }
    if (msg.dir === 'out' && (msg.status === 'failed' || msg.status === 'canceled')) {
      const btn = document.createElement('button');
      btn.className = 'mini-btn';
      btn.dataset.act = 'resend';
      btn.dataset.id = msg.id;
      btn.textContent = '重新选择文件发送';
      actions.appendChild(btn);
    }
    if (!actions.children.length) actions.remove();

    wrap.appendChild(card);
  }

  const meta = document.createElement('div');
  meta.className = 'meta';
  meta.innerHTML = `${fmtClock(msg.ts)}${msg.via === 'server' ? ' · 经服务器中转' : ''}${
    msg.kind === 'text' && msg.status === 'failed' ? ' · <span class="state-failed">发送失败</span>' : ''
  }`;
  wrap.appendChild(meta);

  return wrap;
}

export function autoGrow(textarea) {
  textarea.style.height = 'auto';
  textarea.style.height = `${Math.min(148, textarea.scrollHeight)}px`;
}

export function isMobile() {
  return window.matchMedia('(max-width: 820px)').matches;
}
