#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"

if command -v node >/dev/null 2>&1; then
  NODE_EXE=node
elif [ -x "$HOME/.workbuddy/binaries/node/versions/22.22.2-2/node" ]; then
  NODE_EXE="$HOME/.workbuddy/binaries/node/versions/22.22.2-2/node"
else
  echo "没有找到 Node.js，请先安装：https://nodejs.org"
  exit 1
fi

echo "正在启动服务（Ctrl+C 停止）…"
exec "$NODE_EXE" server/index.js
