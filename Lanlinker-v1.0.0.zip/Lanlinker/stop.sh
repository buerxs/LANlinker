#!/usr/bin/env bash
# 停止Lanlinker服务
# 用法：./stop.sh [端口]    例如 ./stop.sh 8080
cd "$(dirname "$0")"
PORT="${1:-5178}"

echo ""
echo "  正在检查端口 $PORT ..."
echo ""

# 1. 确认该端口上跑的确实是本项目服务，避免误杀别的程序
if ! curl -s --noproxy '*' --max-time 3 "http://127.0.0.1:$PORT/healthz" 2>/dev/null | grep -q '"ok"'; then
  echo "  端口 $PORT 上没有运行中的「Lanlinker」服务。"
  echo ""
  echo "  如果启动时改过端口，请把端口号告诉本脚本，例如：./stop.sh 8080"
  exit 0
fi

# 2. 优先走优雅关闭接口：服务端先保存数据、断开连接再退出
echo "  已找到运行中的服务，正在请求优雅关闭..."
curl -s --noproxy '*' --max-time 3 -X POST "http://127.0.0.1:$PORT/api/local/shutdown" >/dev/null 2>&1
sleep 3

if ! curl -s --noproxy '*' --max-time 2 "http://127.0.0.1:$PORT/healthz" 2>/dev/null | grep -q '"ok"'; then
  echo "  服务已停止。"
  echo ""
  exit 0
fi

# 3. 优雅关闭没生效（旧版本服务端等），按端口结束进程
echo "  优雅关闭未生效，改为结束进程..."
PIDS=$(lsof -ti "tcp:$PORT" 2>/dev/null || true)
if [ -z "$PIDS" ]; then
  PIDS=$(pgrep -f "server/index.js" 2>/dev/null || true)
fi
if [ -z "$PIDS" ]; then
  echo "  找不到对应进程，服务可能已经停止。"
  echo ""
  exit 0
fi

echo "  正在停止进程：$PIDS"
kill $PIDS 2>/dev/null || true
sleep 2
kill -9 $PIDS 2>/dev/null || true

if curl -s --noproxy '*' --max-time 2 "http://127.0.0.1:$PORT/healthz" 2>/dev/null | grep -q '"ok"'; then
  echo "  服务仍在运行，请手动 kill：$PIDS"
else
  echo "  服务已停止。"
fi
echo ""
