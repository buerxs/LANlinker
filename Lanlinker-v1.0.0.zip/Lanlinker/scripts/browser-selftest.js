'use strict';

/**
 * 用本机已安装的 Chromium 内核浏览器（Edge / Chrome）以 headless 模式打开
 * /selftest.html，在真实浏览器里跑通 WebRTC DataChannel 的收发全流程，
 * 再把页面内的测试结果打印到终端。
 *
 * 运行：node scripts/browser-selftest.js   （需先启动服务：node server/index.js）
 */

const { spawn } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');

const URL_TO_TEST = process.env.SELFTEST_URL || 'http://127.0.0.1:5178/selftest.html';
const CDP_PORT = Number(process.env.CDP_PORT || 9411);

const CANDIDATES = [
  'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',
  'C:/Program Files/Microsoft/Edge/Application/msedge.exe',
  'C:/Program Files/Google/Chrome/Application/chrome.exe',
  'C:/Program Files (x86)/Google/Chrome/Application/chrome.exe',
  '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
  '/usr/bin/google-chrome',
  '/usr/bin/chromium',
];

function findBrowser() {
  for (const p of CANDIDATES) if (fs.existsSync(p)) return p;
  return null;
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function main() {
  const bin = findBrowser();
  if (!bin) {
    console.error('没有找到 Edge / Chrome，跳过浏览器自检');
    process.exit(2);
  }
  console.log('使用浏览器：' + bin);

  const profile = fs.mkdtempSync(path.join(os.tmpdir(), 'lanlinker-cdp-'));
  const child = spawn(bin, [
    '--headless=new',
    `--remote-debugging-port=${CDP_PORT}`,
    `--user-data-dir=${profile}`,
    '--no-first-run',
    '--no-default-browser-check',
    '--disable-gpu',
    '--no-proxy-server',
    '--proxy-bypass-list=<-loopback>',
    'about:blank',
  ], { stdio: 'ignore' });

  let target = null;
  for (let i = 0; i < 80 && !target; i++) {
    await sleep(250);
    try {
      const res = await fetch(`http://127.0.0.1:${CDP_PORT}/json/list`);
      const list = await res.json();
      target = list.find((t) => t.type === 'page');
    } catch { /* 还没起来 */ }
  }
  if (!target) {
    child.kill();
    console.error('浏览器调试端口未就绪');
    process.exit(1);
  }

  const ws = new WebSocket(target.webSocketDebuggerUrl);
  let id = 0;
  const pending = new Map();

  await new Promise((resolve, reject) => {
    ws.onopen = resolve;
    ws.onerror = () => reject(new Error('CDP 连接失败'));
  });

  ws.onmessage = (evt) => {
    const msg = JSON.parse(evt.data);
    if (msg.id && pending.has(msg.id)) {
      pending.get(msg.id)(msg);
      pending.delete(msg.id);
    } else if (msg.method === 'Runtime.consoleAPICalled') {
      const text = (msg.params.args || []).map((a) => a.value ?? a.description ?? '').join(' ');
      if (msg.params.type === 'error') console.log('  [页面 console.error] ' + text);
    } else if (msg.method === 'Runtime.exceptionThrown') {
      const d = msg.params.exceptionDetails;
      console.log('  [页面异常] ' + (d.exception ? d.exception.description : d.text));
    }
  };

  const send = (method, params = {}) => new Promise((resolve) => {
    const msgId = ++id;
    pending.set(msgId, resolve);
    ws.send(JSON.stringify({ id: msgId, method, params }));
  });

  const evaluate = async (expression) => {
    const res = await send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true });
    return res.result && res.result.result ? res.result.result.value : undefined;
  };

  await send('Runtime.enable');
  await send('Page.enable');
  await send('Page.navigate', { url: URL_TO_TEST });

  let status = '';
  for (let i = 0; i < 200; i++) {
    await sleep(300);
    status = (await evaluate("document.getElementById('status') ? document.getElementById('status').textContent : ''")) || '';
    if (status.startsWith('DONE')) break;
  }

  const logText = await evaluate("document.getElementById('log') ? document.getElementById('log').textContent : ''");
  console.log('\n———— 浏览器内自检输出 ————');
  console.log(logText || '(无输出)');
  console.log('———— 状态：' + (status || '未完成') + ' ————\n');

  try {
    ws.close();
  } catch { /* ignore */ }
  child.kill();
  await sleep(300);
  try {
    fs.rmSync(profile, { recursive: true, force: true });
  } catch { /* ignore */ }

  const m = /fail=(\d+)/.exec(status);
  process.exit(status.startsWith('DONE') && m && m[1] === '0' ? 0 : 1);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
