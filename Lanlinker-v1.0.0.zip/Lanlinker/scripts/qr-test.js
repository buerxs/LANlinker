/**
 * QR 编码器正确性测试。
 *
 * 参考矩阵由 scripts/_qr_ref.py 用 Python segno 库生成。
 * 注意：segno 与本项目在「结束符之后的填充字节」上约定不同（它会多填一个 0x00），
 * 填充内容不影响扫码（解码器读到结束符即停止），所以不能要求整张矩阵完全相同。
 * 改为比对三件真正要紧的事：
 *   1. 所有功能图形（定位/定时/校正/格式/版本信息）逐格一致
 *   2. 有效载荷比特（模式 + 计数 + 数据 + 结束符）完全一致
 *   3. 自己生成的矩阵能原样解码回原文（往返验证）
 *
 * 运行：node scripts/qr-test.js
 */
'use strict';

const fs = require('fs');
const path = require('path');

const src = fs
  .readFileSync(path.join(__dirname, '..', 'public', 'js', 'qr.js'), 'utf8')
  .replace(/^\s*export\s+/gm, '');
const { qrMatrix } = new Function(`${src}\nreturn { qrMatrix, drawQr };`)();

const refPath = path.join(__dirname, 'qr-ref.json');
if (!fs.existsSync(refPath)) {
  console.error('缺少参考矩阵，请先运行：');
  console.error('  <venv>\\Scripts\\python.exe scripts/_qr_ref.py scripts/qr-ref.json');
  process.exit(1);
}
const refs = JSON.parse(fs.readFileSync(refPath, 'utf8'));

let passed = 0;
let failed = 0;
const check = (cond, label, detail = '') => {
  if (cond) {
    passed++;
    console.log(`  ✅ ${label}`);
  } else {
    failed++;
    console.log(`  ❌ ${label}${detail ? `  → ${detail}` : ''}`);
  }
};

function maskInvert(mask, x, y) {
  switch (mask) {
    case 0: return (x + y) % 2 === 0;
    case 1: return y % 2 === 0;
    case 2: return x % 3 === 0;
    case 3: return (x + y) % 3 === 0;
    case 4: return (Math.floor(x / 3) + Math.floor(y / 2)) % 2 === 0;
    case 5: return ((x * y) % 2) + ((x * y) % 3) === 0;
    case 6: return (((x * y) % 2) + ((x * y) % 3)) % 2 === 0;
    case 7: return (((x + y) % 2) + ((x * y) % 3)) % 2 === 0;
    default: return false;
  }
}

/** 按放置顺序读回数据比特（跳过功能图形，并去掉掩码） */
function readDataBits(getCell, isFn, size, mask) {
  const bits = [];
  for (let right = size - 1; right >= 1; right -= 2) {
    if (right === 6) right = 5;
    for (let vert = 0; vert < size; vert++) {
      for (let j = 0; j < 2; j++) {
        const x = right - j;
        const upward = ((right + 1) & 2) === 0;
        const y = upward ? size - 1 - vert : vert;
        if (isFn[y][x]) continue;
        let v = getCell(y, x);
        if (maskInvert(mask, x, y)) v = !v;
        bits.push(v ? 1 : 0);
      }
    }
  }
  return bits;
}

console.log('\nQR 编码器测试（对照 Python segno）\n');

for (const ref of refs) {
  const out = qrMatrix(ref.text, ref.mask); // 强制用参考掩码，排除掩码选择差异
  const size = out.size;
  const label = `"${ref.text.length > 26 ? `${ref.text.slice(0, 26)}…` : ref.text}"`;
  const theirs = ref.rows.map((r) => r.split('').map(Number));

  check(out.version === ref.version, `${label} 版本一致 (v${ref.version})`, `实得 v${out.version}`);
  check(size === ref.size, `${label} 尺寸一致 (${ref.size})`, `实得 ${size}`);

  // 1. 功能图形逐格一致
  let fnDiff = 0;
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      if (!out.isFn[y][x]) continue;
      if ((out.matrix[y][x] ? 1 : 0) !== theirs[y][x]) fnDiff++;
    }
  }
  check(fnDiff === 0, `${label} 功能图形逐格一致`, `差异 ${fnDiff} 格`);

  // 2. 有效载荷比特一致（模式4 + 计数 + 数据 + 结束符4）
  const countBits = out.version < 10 ? 8 : 16;
  const payloadLen = 4 + countBits + new TextEncoder().encode(ref.text).length * 8 + 4;
  const mineBits = readDataBits((y, x) => out.matrix[y][x], out.isFn, size, out.mask);
  const refBits = readDataBits((y, x) => !!theirs[y][x], out.isFn, size, ref.mask);
  let payloadDiff = 0;
  for (let i = 0; i < payloadLen; i++) if (mineBits[i] !== refBits[i]) payloadDiff++;
  check(payloadDiff === 0, `${label} 有效载荷比特一致（前 ${payloadLen} 位）`, `差异 ${payloadDiff} 位`);

  // 3. 往返：自己解码自己
  const decoded = decodeBits(mineBits, out.version);
  check(decoded === ref.text, `${label} 可原样解码回原文`, `解出 "${decoded}"`);
}

/** 从数据比特流里解出文本（无纠错，因为自己生成的码没有噪声） */
function decodeBits(bits, version) {
  let p = 0;
  const take = (n) => {
    let v = 0;
    for (let i = 0; i < n; i++) v = (v << 1) | bits[p++];
    return v;
  };
  const mode = take(4);
  if (mode !== 0b0100) return `<非字节模式:${mode}>`;
  const len = take(version < 10 ? 8 : 16);
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) bytes[i] = take(8);
  return new TextDecoder().decode(bytes);
}

/* ---------------- 边界情况 ---------------- */

let threw = false;
try {
  qrMatrix('x'.repeat(300));
} catch {
  threw = true;
}
check(threw, '超长内容（300 字节）抛出错误而不是生成坏码');

try {
  const zh = qrMatrix('你好，Lanlinker');
  const bits = readDataBits((y, x) => zh.matrix[y][x], zh.isFn, zh.size, zh.mask);
  check(decodeBits(bits, zh.version) === '你好，Lanlinker', '中文内容可编码并解码回来');
} catch (err) {
  check(false, '中文内容可编码并解码回来', err.message);
}

// 掩码选择要稳定：同一文本多次生成结果一致
const a1 = qrMatrix('http://192.168.0.103:5178');
const a2 = qrMatrix('http://192.168.0.103:5178');
check(a1.mask === a2.mask && JSON.stringify(a1.matrix) === JSON.stringify(a2.matrix), '同一文本生成结果稳定');

console.log(`\n结果：${passed} 项通过，${failed} 项失败\n`);
process.exit(failed === 0 ? 0 : 1);
