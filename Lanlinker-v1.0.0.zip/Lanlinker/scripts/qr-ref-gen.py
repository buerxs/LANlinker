import json, sys
import segno

STRINGS = [
    "A",
    "http://10.0.0.2:5178",
    "http://192.168.0.103:5178",
    "http://192.168.1.200:8080/index.html",
    "hello world hello world hello world",
    "http://172.16.254.1:5178/?newdevice=1",
]

out = []
for s in STRINGS:
    q = segno.make(s, mode='byte', error='m', boost_error=False, micro=False)
    m = q.matrix
    rows = [''.join('1' if v else '0' for v in row) for row in m]
    out.append({
        'text': s,
        'version': q.version,
        'mask': q.mask,
        'size': len(rows),
        'rows': rows,
    })

json.dump(out, open(sys.argv[1], 'w'), ensure_ascii=False)
for o in out:
    print(f"{o['text'][:40]:42} v{o['version']} mask={o['mask']} size={o['size']}")
