'use strict';

/**
 * 完整 UI 流程验证：启动两个互相独立的 headless 浏览器（等于两台真实设备），
 * 走一遍「注册 → 另一台登录 → 自动出现在设备列表 → 建立 P2P → 互发文字 → 拖拽发文件」。
 *
 * 运行前需先启动服务：node server/index.js
 *   node scripts/browser-ui-check.js
 */

const { spawn } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');

const BASE = process.env.UI_CHECK_BASE || 'http://127.0.0.1:5178';

const CANDIDATES = [
  'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',
  'C:/Program Files/Microsoft/Edge/Application/msedge.exe',
  'C:/Program Files/Google/Chrome/Application/chrome.exe',
  'C:/Program Files (x86)/Google/Chrome/Application/chrome.exe',
  '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
  '/usr/bin/google-chrome',
  '/usr/bin/chromium',
];

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

let passed = 0;
let failed = 0;
function check(cond, label, detail = '') {
  if (cond) {
    passed++;
    console.log(`  ✅ ${label}`);
  } else {
    failed++;
    console.log(`  ❌ ${label}${detail ? `  → ${detail}` : ''}`);
  }
}

class Browser {
  constructor(label, bin, port) {
    this.label = label;
    this.bin = bin;
    this.port = port;
    this.msgId = 0;
    this.pending = new Map();
    this.errors = [];
  }

  static find() {
    for (const p of CANDIDATES) if (fs.existsSync(p)) return p;
    return null;
  }

  async launch() {
    this.profile = fs.mkdtempSync(path.join(os.tmpdir(), 'lanlinker-ui-'));
    this.child = spawn(this.bin, [
      '--headless=new',
      `--remote-debugging-port=${this.port}`,
      `--user-data-dir=${this.profile}`,
      '--no-first-run',
      '--no-default-browser-check',
      '--disable-gpu',
      '--no-proxy-server',
      '--proxy-bypass-list=<-loopback>',
      'about:blank',
    ], { stdio: 'ignore' });

    let target = null;
    for (let i = 0; i < 80 && !target; i++) {
      await sleep(250);
      try {
        const res = await fetch(`http://127.0.0.1:${this.port}/json/list`);
        target = (await res.json()).find((t) => t.type === 'page');
      } catch { /* 等待启动 */ }
    }
    if (!target) throw new Error(`${this.label} 调试端口未就绪`);

    this.ws = new WebSocket(target.webSocketDebuggerUrl);
    await new Promise((resolve, reject) => {
      this.ws.onopen = resolve;
      this.ws.onerror = () => reject(new Error(`${this.label} CDP 连接失败`));
    });
    this.ws.onmessage = (evt) => {
      const msg = JSON.parse(evt.data);
      if (msg.id && this.pending.has(msg.id)) {
        this.pending.get(msg.id)(msg);
        this.pending.delete(msg.id);
      } else if (msg.method === 'Runtime.exceptionThrown') {
        const d = msg.params.exceptionDetails;
        this.errors.push(d.exception ? d.exception.description : d.text);
      } else if (msg.method === 'Runtime.consoleAPICalled' && msg.params.type === 'error') {
        this.errors.push((msg.params.args || []).map((a) => a.value ?? a.description ?? '').join(' '));
      }
    };
    await this.send('Runtime.enable');
    await this.send('Page.enable');
    return this;
  }

  send(method, params = {}) {
    return new Promise((resolve) => {
      const id = ++this.msgId;
      this.pending.set(id, resolve);
      this.ws.send(JSON.stringify({ id, method, params }));
    });
  }

  async eval(expression) {
    const res = await this.send('Runtime.evaluate', {
      expression: `(()=>{ ${expression} })()`,
      returnByValue: true,
      awaitPromise: true,
    });
    const r = res.result || {};
    if (r.exceptionDetails) {
      throw new Error(`${this.label} 求值异常：${r.exceptionDetails.exception
        ? r.exceptionDetails.exception.description : r.exceptionDetails.text}`);
    }
    return r.result ? r.result.value : undefined;
  }

  async navigate(url) {
    await this.send('Page.navigate', { url });
  }

  async waitFor(expression, label, timeout = 25000) {
    const t0 = Date.now();
    for (;;) {
      let v;
      try {
        v = await this.eval(`return ${expression};`);
      } catch { v = undefined; }
      if (v) return v;
      if (Date.now() - t0 > timeout) throw new Error(`${this.label} 等待超时：${label}`);
      await sleep(200);
    }
  }

  close() {
    try { this.ws.close(); } catch { /* ignore */ }
    try { this.child.kill(); } catch { /* ignore */ }
    try { fs.rmSync(this.profile, { recursive: true, force: true }); } catch { /* ignore */ }
  }
}

async function main() {
  const bin = Browser.find();
  if (!bin) {
    console.error('没有找到 Edge / Chrome，跳过 UI 检查');
    process.exit(2);
  }
  console.log(`使用浏览器：${bin}\n服务地址：${BASE}\n`);

  const account = `ui测试${Date.now().toString().slice(-6)}`;
  const password = 'ui-test-123456';

  const b1 = new Browser('设备一', bin, 9431);
  const b2 = new Browser('设备二', bin, 9432);

  try {
    await b1.launch();
    await b2.launch();

    /* -------- 设备一：注册 -------- */
    await b1.navigate(`${BASE}/`);
    await b1.waitFor("!document.getElementById('splash')", '首屏加载完成');
    check(true, '设备一 页面加载完成，模块脚本无阻塞错误');

    await b1.eval(`
      document.querySelector('[data-mode="register"]').click();
      document.getElementById('auth-username').value = ${JSON.stringify(account)};
      document.getElementById('auth-password').value = ${JSON.stringify(password)};
      document.getElementById('auth-confirm').value = ${JSON.stringify(password)};
      document.getElementById('auth-form').dispatchEvent(new Event('submit', { bubbles: true, cancelable: true }));
      return true;
    `);
    await b1.waitFor("!document.getElementById('view-app').hidden", '进入主界面');
    check(true, '设备一 注册成功并进入主界面');
    await b1.waitFor("document.getElementById('ws-state').textContent === '已连接'", '服务器连接');
    check(true, '设备一 WebSocket 已连接（设备自动绑定）');
    const emptyHint = await b1.eval("return document.querySelector('#device-list').textContent;");
    check(emptyHint.includes('还没有其它设备'), '设备一 正确显示「还没有其它设备」空状态');

    // 侧栏要显示服务端当前的局域网地址（IP 随 DHCP 变化时靠它找服务）
    const lanAddr = await b1.eval(`
      const row = document.getElementById('addr-row');
      return row && !row.hidden ? document.getElementById('lan-addr').textContent.trim() : '';
    `);
    const addrOk =
      lanAddr.startsWith('http://') &&
      lanAddr.split('//')[1].split(':')[0].split('.').length === 4 &&
      lanAddr.split(':').length === 3;
    check(addrOk, '设备一 侧栏显示本机局域网地址', lanAddr);
    check(lanAddr.endsWith(`:${new URL(BASE).port}`), '显示的地址端口与被测服务一致', lanAddr);

    // 点「二维码」要能画出码（用深色像素占比确认真的画了东西，不是空白画布）
    const qr = await b1.eval(`
      document.getElementById('btn-qr').click();
      const wrap = document.getElementById('qr-wrap');
      const cv = document.getElementById('qr-canvas');
      if (wrap.hidden || !cv.width) return { shown: false, darkRatio: 0 };
      const d = cv.getContext('2d').getImageData(0, 0, cv.width, cv.height).data;
      let dark = 0;
      for (let i = 0; i < d.length; i += 4) if (d[i] < 128) dark++;
      return { shown: true, darkRatio: dark / (d.length / 4) };
    `);
    check(qr.shown, '设备一 点击后展开二维码', JSON.stringify(qr));
    check(qr.darkRatio > 0.2 && qr.darkRatio < 0.8, '二维码画布有实际内容', `深色占比 ${(qr.darkRatio * 100).toFixed(1)}%`);

    /* -------- 设备二：同账号登录 -------- */
    await b2.navigate(`${BASE}/`);
    await b2.waitFor("!document.getElementById('splash')", '首屏加载完成');
    await b2.eval(`
      document.getElementById('auth-username').value = ${JSON.stringify(account)};
      document.getElementById('auth-password').value = ${JSON.stringify(password)};
      document.getElementById('auth-form').dispatchEvent(new Event('submit', { bubbles: true, cancelable: true }));
      return true;
    `);
    await b2.waitFor("!document.getElementById('view-app').hidden", '进入主界面');
    check(true, '设备二 用同一账号登录成功');

    /* -------- 设备列表自动刷新 -------- */
    await b1.waitFor("document.querySelectorAll('#device-list .device').length === 1", '设备一看到设备二');
    check(true, '设备二上线后，设备一的列表自动出现该设备（无需刷新）');
    const badgeText = await b1.eval("return document.querySelector('#device-list .device').textContent;");
    check(badgeText.includes('同一局域网'), '设备一 标记对端为「同一局域网」', badgeText.trim());
    await b2.waitFor("document.querySelectorAll('#device-list .device').length === 1", '设备二看到设备一');
    check(true, '设备二 同样看到设备一');

    /* -------- 建立 P2P -------- */
    await b1.eval("document.querySelector('#device-list .device').click(); return true;");
    await b1.waitFor("document.getElementById('conn-badge').dataset.state === 'connected'", 'P2P 连接建立');
    check(true, '点击设备后成功建立 WebRTC 点对点连接');

    /* -------- 文字互发 -------- */
    const text1 = '你好，这是设备一发来的消息 👋';
    await b1.eval(`
      document.getElementById('input-text').value = ${JSON.stringify(text1)};
      document.getElementById('composer').dispatchEvent(new Event('submit', { bubbles: true, cancelable: true }));
      return true;
    `);
    await b2.waitFor("!!document.querySelector('#device-list .unread')", '设备二收到未读提醒');
    check(true, '设备二 收到消息并显示未读红点');

    await b2.eval("document.querySelector('#device-list .device').click(); return true;");
    await b2.waitFor(`document.getElementById('messages').textContent.includes(${JSON.stringify(text1)})`, '消息渲染');
    check(true, '设备二 打开会话后正确显示收到的文字');
    const noRelay = await b2.eval("return !document.getElementById('messages').textContent.includes('经服务器中转');");
    check(noRelay, '文字确实走的 P2P（未出现「经服务器中转」标记）');

    const text2 = '收到了！这是设备二的回复';
    await b2.eval(`
      document.getElementById('input-text').value = ${JSON.stringify(text2)};
      document.getElementById('composer').dispatchEvent(new Event('submit', { bubbles: true, cancelable: true }));
      return true;
    `);
    await b1.waitFor(`document.getElementById('messages').textContent.includes(${JSON.stringify(text2)})`, '回复渲染');
    check(true, '设备一 收到设备二的回复（双向通信正常）');

    /* -------- 拖拽发送文件 -------- */
    await b1.eval(`
      const bytes = new Uint8Array(180 * 1024);
      for (let i = 0; i < bytes.length; i++) bytes[i] = (i * 13 + 7) & 0xff;
      const dt = new DataTransfer();
      dt.items.add(new File([bytes], '拖拽测试.bin', { type: 'application/octet-stream' }));
      document.getElementById('chat-inner').dispatchEvent(new DragEvent('drop', { dataTransfer: dt, bubbles: true, cancelable: true }));
      return true;
    `);
    await b2.waitFor("document.getElementById('messages').textContent.includes('接收完成')", '文件接收完成', 40000);
    check(true, '设备二 通过拖拽收到文件并显示「接收完成」');
    const hasSave = await b2.eval("return !!Array.from(document.querySelectorAll('#messages a.mini-btn')).find(a => a.textContent.includes('保存'));");
    check(hasSave, '接收方出现「保存到本机」下载按钮');
    const fileName = await b2.eval("return document.getElementById('messages').textContent.includes('拖拽测试.bin');");
    check(fileName, '文件名（中文）显示正确');
    await b1.waitFor("document.getElementById('messages').textContent.includes('对方已接收')", '收到 ACK');
    check(true, '发送方收到接收确认（显示「对方已接收」）');

    /* -------- 离线状态刷新 -------- */
    await b2.eval("window.__closed = true; return true;");
    b2.close();
    await b1.waitFor("document.querySelector('#device-list .device').classList.contains('is-offline')", '对端离线', 20000);
    check(true, '设备二关闭后，设备一的列表自动变为离线状态');

    /* -------- 控制台错误 -------- */
    const realErrors = b1.errors.filter((e) => !/favicon|Failed to load resource/i.test(e));
    check(realErrors.length === 0, '设备一 全程无 JS 运行时错误', realErrors.join(' | ').slice(0, 300));
  } catch (err) {
    failed++;
    console.log(`  ❌ 流程中断：${err.message}`);
  } finally {
    b1.close();
    b2.close();
  }

  console.log(`\n结果：${passed} 项通过，${failed} 项失败\n`);
  process.exit(failed ? 1 : 0);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
