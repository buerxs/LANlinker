'use strict';

/**
 * 端到端冒烟测试：模拟两台设备完成
 *   注册 / 登录 → WebSocket 握手 → 自动绑定设备 → 在线列表实时推送
 *   → WebRTC 信令转发 → 文字兜底中转 → 改名 / 离线通知 / 冲突与鉴权
 *
 * 运行：node scripts/smoke-test.js
 */

const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');
const os = require('os');

const PORT = Number(process.env.TEST_PORT || 5399);
const BASE = `http://127.0.0.1:${PORT}`;
const ROOT = path.join(__dirname, '..');
const DATA_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'lanlinker-test-'));

let passed = 0;
let failed = 0;

function ok(label, extra = '') {
  passed++;
  console.log(`  ✅ ${label}${extra ? `  ${extra}` : ''}`);
}
function bad(label, detail = '') {
  failed++;
  console.log(`  ❌ ${label}${detail ? `  → ${detail}` : ''}`);
}
function assert(cond, label, detail = '') {
  if (cond) ok(label);
  else bad(label, detail);
  return cond;
}

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

async function jsonFetch(pathname, { method = 'GET', body, token } = {}) {
  const headers = {};
  if (body) headers['Content-Type'] = 'application/json';
  if (token) headers['Authorization'] = `Bearer ${token}`;
  const res = await fetch(BASE + pathname, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
  });
  let data = null;
  try {
    data = await res.json();
  } catch { /* ignore */ }
  return { status: res.status, data };
}

/** 简易 WS 客户端封装（Node 22 内置 WebSocket） */
class Client {
  constructor(label) {
    this.label = label;
    this.inbox = [];
    this.waiters = [];
    this.ws = null;
  }

  connect() {
    return new Promise((resolve, reject) => {
      const ws = new WebSocket(`ws://127.0.0.1:${PORT}/ws`);
      this.ws = ws;
      ws.onopen = () => resolve();
      ws.onerror = () => reject(new Error(`${this.label} WebSocket 连接失败`));
      ws.onmessage = (evt) => {
        let msg;
        try {
          msg = JSON.parse(evt.data);
        } catch {
          return;
        }
        this.inbox.push(msg);
        for (let i = this.waiters.length - 1; i >= 0; i--) {
          const w = this.waiters[i];
          if (w.match(msg)) {
            this.waiters.splice(i, 1);
            w.resolve(msg);
          }
        }
      };
      ws.onclose = () => { this.closed = true; };
    });
  }

  send(obj) {
    this.ws.send(JSON.stringify(obj));
  }

  /** 等待满足条件的消息（含已到达的） */
  wait(match, timeout = 4000) {
    const idx = this.inbox.findIndex(match);
    if (idx > -1) return Promise.resolve(this.inbox[idx]);
    return new Promise((resolve, reject) => {
      const waiter = { match, resolve };
      this.waiters.push(waiter);
      setTimeout(() => {
        const i = this.waiters.indexOf(waiter);
        if (i > -1) {
          this.waiters.splice(i, 1);
          reject(new Error(`${this.label} 等待消息超时`));
        }
      }, timeout);
    });
  }

  waitType(t, timeout) {
    return this.wait((m) => m.t === t, timeout);
  }

  clear() {
    this.inbox = [];
  }

  close() {
    try {
      this.ws.close();
    } catch { /* ignore */ }
  }
}

async function waitForServer(timeoutMs = 15000) {
  const started = Date.now();
  while (Date.now() - started < timeoutMs) {
    try {
      const res = await fetch(`${BASE}/healthz`);
      if (res.ok) return true;
    } catch { /* 还没起来 */ }
    await sleep(150);
  }
  return false;
}

async function main() {
  console.log('\n启动测试服务器…');
  const child = spawn(process.execPath, [path.join(ROOT, 'server', 'index.js')], {
    cwd: ROOT,
    env: { ...process.env, PORT: String(PORT), LANLINKER_DATA_DIR: DATA_DIR },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  let serverLog = '';
  child.stdout.on('data', (d) => { serverLog += d.toString(); });
  child.stderr.on('data', (d) => { serverLog += d.toString(); });

  const up = await waitForServer();
  if (!up) {
    console.error('服务器启动失败：\n' + serverLog);
    child.kill();
    process.exit(1);
  }
  ok('服务器启动并响应 /healthz');

  const account = `测试账号${Date.now().toString().slice(-6)}`;
  const password = 'test-pass-123';
  const devA = 'devA' + '0'.repeat(12);
  const devB = 'devB' + '0'.repeat(12);

  try {
    /* ---------- 账号 ---------- */
    const reg = await jsonFetch('/api/register', { method: 'POST', body: { username: account, password } });
    assert(reg.status === 200 && reg.data.token, '注册账号并返回 token');

    const dup = await jsonFetch('/api/register', { method: 'POST', body: { username: account, password } });
    assert(dup.status === 409, '重复注册被拒绝', `status=${dup.status}`);

    const weak = await jsonFetch('/api/register', { method: 'POST', body: { username: 'x2', password: '123' } });
    assert(weak.status === 400, '弱密码被拒绝', `status=${weak.status}`);

    const badLogin = await jsonFetch('/api/login', { method: 'POST', body: { username: account, password: 'wrong' } });
    assert(badLogin.status === 401, '错误密码登录被拒绝', `status=${badLogin.status}`);

    const login = await jsonFetch('/api/login', { method: 'POST', body: { username: account, password } });
    assert(login.status === 200 && login.data.token, '正确密码登录成功');
    const tokenA = reg.data.token;
    const tokenB = login.data.token;

    /* ---------- 登录限流 ---------- */
    let lastStatus = 0;
    for (let i = 0; i < 20; i++) {
      const r = await jsonFetch('/api/login', { method: 'POST', body: { username: account, password: 'wrong-' + i } });
      lastStatus = r.status;
      if (r.status === 429) break;
    }
    assert(lastStatus === 429, '连续错误密码触发限流（429）', `lastStatus=${lastStatus}`);
    const blocked = await jsonFetch('/api/login', { method: 'POST', body: { username: account, password } });
    assert(blocked.status === 429, '限流期间正确密码也被暂时拒绝（防爆破）', `status=${blocked.status}`);

    /* ---------- 设备 1 上线 ---------- */
    const a = new Client('设备A');
    await a.connect();
    a.send({ t: 'hello', token: tokenA, deviceId: devA, name: '台式机', platform: 'Windows / Chrome' });
    const welcomeA = await a.waitType('welcome');
    assert(welcomeA.self.deviceId === devA, '设备A 完成握手并自动绑定');
    assert(Boolean(welcomeA.lanId), '服务端识别出局域网标识', welcomeA.lanId);

    const listA1 = await a.waitType('devices');
    assert(listA1.devices.length === 1 && listA1.devices[0].self, '设备列表包含自己');

    /* ---------- 设备 2 上线（同账号，另一个 token） ---------- */
    const b = new Client('设备B');
    await b.connect();
    a.clear();
    b.send({ t: 'hello', token: tokenB, deviceId: devB, name: '手机', platform: 'Android / Chrome' });
    await b.waitType('welcome');

    const pushA = await a.wait((m) => m.t === 'devices' && m.devices.length === 2);
    assert(true, '设备B 上线后，设备A 收到实时推送');
    const bInA = pushA.devices.find((d) => d.id === devB);
    assert(bInA && bInA.online === true, '设备B 在列表中显示为在线');
    assert(bInA && bInA.sameLan === true, '判定两台设备处于同一局域网');
    assert(bInA && bInA.name === '手机', '设备名正确同步', bInA && bInA.name);

    /* ---------- 信令转发 ---------- */
    b.clear();
    const fakeSdp = 'v=0\r\n' + 'a=x'.repeat(50000); // ≈150KB，同时检验大帧解析
    a.send({ t: 'signal', to: devB, payload: { description: { type: 'offer', sdp: fakeSdp } } });
    const sig = await b.waitType('signal');
    assert(sig.from === devA, '信令携带正确的来源设备');
    assert(sig.payload.description.sdp.length === fakeSdp.length, '大体积 SDP（≈150KB）完整转发');

    a.clear();
    b.send({ t: 'signal', to: devA, payload: { candidate: { candidate: 'candidate:1 1 udp 2113 192.168.1.9 55555 typ host' } } });
    const cand = await a.waitType('signal');
    assert(cand.payload.candidate.candidate.includes('typ host'), 'candidate 反向转发正常');

    /* ---------- 文字兜底中转 ---------- */
    b.clear();
    a.send({ t: 'relay', to: devB, payload: { k: 'text', id: 'm1', text: '你好，局域网！' } });
    const relayed = await b.waitType('relay');
    assert(relayed.payload.text === '你好，局域网！', '文字消息经服务器中转成功');

    /* ---------- 发给不存在的设备 ---------- */
    a.clear();
    a.send({ t: 'signal', to: 'devZ' + '0'.repeat(12), payload: { req: 'connect' } });
    const gone = await a.waitType('peer-gone');
    assert(gone.peer.startsWith('devZ'), '目标设备不在线时返回 peer-gone');

    /* ---------- 改名 ---------- */
    a.clear();
    b.send({ t: 'rename', name: '我的手机' });
    const renamed = await a.wait((m) => m.t === 'devices' && m.devices.some((d) => d.name === '我的手机'));
    assert(Boolean(renamed), '改名后设备列表实时刷新');

    /* ---------- HTTP 设备接口 ---------- */
    const devices = await jsonFetch('/api/devices', { token: tokenA });
    assert(devices.status === 200 && devices.data.devices.length === 2, 'GET /api/devices 返回两台设备');
    const noAuth = await jsonFetch('/api/devices');
    assert(noAuth.status === 401, '未带 token 访问设备接口被拒绝');

    /* ---------- 同设备重复连接冲突 ---------- */
    const dupConn = new Client('设备B副本');
    await dupConn.connect();
    dupConn.send({ t: 'hello', token: tokenB, deviceId: devB, name: '手机', platform: 'Android / Chrome' });
    const busy = await dupConn.waitType('error');
    assert(busy.code === 'device_busy', '同一设备重复连接时返回 device_busy');

    /* ---------- 接管连接 ---------- */
    const takeover = new Client('设备B接管');
    await takeover.connect();
    takeover.send({ t: 'hello', token: tokenB, deviceId: devB, name: '手机', platform: 'Android / Chrome', takeover: true });
    const kicked = await b.waitType('kicked');
    assert(kicked.reason === 'takeover', '接管后原连接收到 kicked 通知');
    await takeover.waitType('welcome');
    ok('新窗口接管成功');

    /* ---------- 无效 token ---------- */
    const badWs = new Client('非法token');
    await badWs.connect();
    badWs.send({ t: 'hello', token: 'not-a-real-token', deviceId: devA.replace('A', 'C'), name: 'x' });
    const unauth = await badWs.waitType('error');
    assert(unauth.code === 'unauthorized', '非法 token 的 WebSocket 被拒绝');
    badWs.close();

    /* ---------- 离线通知 ---------- */
    a.clear();
    takeover.close();
    const offline = await a.wait((m) => m.t === 'devices' && m.devices.some((d) => d.id === devB && !d.online), 5000);
    assert(Boolean(offline), '设备下线后对端列表实时更新为离线');
    const peerOffline = a.inbox.find((m) => m.t === 'peer-offline' && m.peer === devB);
    assert(Boolean(peerOffline), '收到 peer-offline 通知');

    /* ---------- 解绑设备 ---------- */
    const forget = await jsonFetch('/api/device/forget', { method: 'POST', token: tokenA, body: { deviceId: devB } });
    assert(forget.status === 200, '解绑设备接口返回成功');
    const after = await jsonFetch('/api/devices', { token: tokenA });
    assert(after.data.devices.length === 1, '解绑后设备列表只剩一台');

    /* ---------- 静态资源 ---------- */
    const page = await fetch(`${BASE}/`);
    const html = await page.text();
    assert(page.ok && html.includes('Lanlinker'), '首页 HTML 正常返回');
    for (const asset of ['/css/style.css', '/js/app.js', '/js/peer.js', '/js/chat.js', '/js/ui.js', '/js/net.js', '/js/api.js', '/js/util.js']) {
      const r = await fetch(BASE + asset);
      assert(r.ok, `静态资源可访问：${asset}`);
    }

    /* ---------- 数据持久化 ---------- */
    const dbFile = path.join(DATA_DIR, 'db.json');
    const db = JSON.parse(fs.readFileSync(dbFile, 'utf8'));
    assert(db.users.length === 1 && db.users[0].username === account, '账号已持久化到 db.json');
    assert(!JSON.stringify(db).includes(password), '数据库中不含明文密码');

    a.close();
    b.close();
    dupConn.close();
  } catch (err) {
    bad('测试执行异常', err.message);
  } finally {
    child.kill();
    await sleep(200);
    try {
      fs.rmSync(DATA_DIR, { recursive: true, force: true });
    } catch { /* ignore */ }
  }

  console.log(`\n结果：${passed} 项通过，${failed} 项失败\n`);
  process.exit(failed ? 1 : 0);
}

main();
