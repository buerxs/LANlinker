'use strict';

/**
 * 生成 App 图标（PNG），零依赖：手写 PNG 编码器（IHDR/IDAT/IEND + CRC32），
 * 用 Node 内置 zlib 压缩像素数据。
 *
 * 运行：node scripts/make-icons.js
 * 产物：public/icons/*.png
 */

const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

const OUT_DIR = path.join(__dirname, '..', 'public', 'icons');

/* ----------------------------- PNG 编码 ----------------------------- */

let CRC_TABLE = null;
function crcTable() {
  if (CRC_TABLE) return CRC_TABLE;
  CRC_TABLE = new Int32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    CRC_TABLE[n] = c;
  }
  return CRC_TABLE;
}

function crc32(buf) {
  const t = crcTable();
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) c = t[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

function chunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length, 0);
  const typeBuf = Buffer.from(type, 'ascii');
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(Buffer.concat([typeBuf, data])), 0);
  return Buffer.concat([len, typeBuf, data, crc]);
}

/** rgba: Uint8Array(width*height*4) → PNG Buffer */
function encodePng(rgba, width, height) {
  const sig = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);

  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8;  // bit depth
  ihdr[9] = 6;  // color type: RGBA
  ihdr[10] = 0; // compression
  ihdr[11] = 0; // filter
  ihdr[12] = 0; // interlace

  // 每行前加一个 filter 字节（0 = None）
  const stride = width * 4;
  const raw = Buffer.alloc((stride + 1) * height);
  for (let y = 0; y < height; y++) {
    raw[y * (stride + 1)] = 0;
    Buffer.from(rgba.buffer, rgba.byteOffset + y * stride, stride).copy(raw, y * (stride + 1) + 1);
  }

  return Buffer.concat([
    sig,
    chunk('IHDR', ihdr),
    chunk('IDAT', zlib.deflateSync(raw, { level: 9 })),
    chunk('IEND', Buffer.alloc(0)),
  ]);
}

/* ----------------------------- 绘图 ----------------------------- */

class Canvas {
  constructor(size) {
    this.size = size;
    this.data = new Uint8Array(size * size * 4);
  }

  set(x, y, [r, g, b, a]) {
    if (x < 0 || y < 0 || x >= this.size || y >= this.size) return;
    const i = (y * this.size + x) * 4;
    if (a >= 255) {
      this.data[i] = r; this.data[i + 1] = g; this.data[i + 2] = b; this.data[i + 3] = 255;
      return;
    }
    // 简单 alpha 混合
    const sa = a / 255;
    const da = this.data[i + 3] / 255;
    const oa = sa + da * (1 - sa);
    if (oa === 0) return;
    this.data[i] = Math.round((r * sa + this.data[i] * da * (1 - sa)) / oa);
    this.data[i + 1] = Math.round((g * sa + this.data[i + 1] * da * (1 - sa)) / oa);
    this.data[i + 2] = Math.round((b * sa + this.data[i + 2] * da * (1 - sa)) / oa);
    this.data[i + 3] = Math.round(oa * 255);
  }

  /** 用「覆盖率」做抗锯齿：每个像素取 3x3 子采样 */
  fill(color, insideFn) {
    const n = 3;
    for (let y = 0; y < this.size; y++) {
      for (let x = 0; x < this.size; x++) {
        let hit = 0;
        for (let sy = 0; sy < n; sy++) {
          for (let sx = 0; sx < n; sx++) {
            const px = (x + (sx + 0.5) / n) / this.size;
            const py = (y + (sy + 0.5) / n) / this.size;
            if (insideFn(px, py)) hit++;
          }
        }
        if (hit) this.set(x, y, [color[0], color[1], color[2], Math.round(255 * hit / (n * n))]);
      }
    }
  }
}

const BLUE = [37, 99, 235];
const WHITE = [255, 255, 255];

const roundedRect = (radius, inset = 0) => (x, y) => {
  const lo = inset;
  const hi = 1 - inset;
  if (x < lo || x > hi || y < lo || y > hi) return false;
  const r = radius;
  const cx = Math.min(Math.max(x, lo + r), hi - r);
  const cy = Math.min(Math.max(y, lo + r), hi - r);
  const dx = x - cx;
  const dy = y - cy;
  return dx * dx + dy * dy <= r * r + 1e-9;
};

const rect = (x0, y0, x1, y1) => (x, y) => x >= x0 && x <= x1 && y >= y0 && y <= y1;

const triangle = (ax, ay, bx, by, cx, cy) => {
  const sign = (px, py, qx, qy, rx, ry) => (px - rx) * (qy - ry) - (qx - rx) * (py - ry);
  return (x, y) => {
    const d1 = sign(x, y, ax, ay, bx, by);
    const d2 = sign(x, y, bx, by, cx, cy);
    const d3 = sign(x, y, cx, cy, ax, ay);
    const hasNeg = d1 < 0 || d2 < 0 || d3 < 0;
    const hasPos = d1 > 0 || d2 > 0 || d3 > 0;
    return !(hasNeg && hasPos);
  };
};

/** 画「⇄」双向箭头：上排向右，下排向左 */
function drawGlyph(canvas, scale = 1) {
  const mid = 0.5;
  const s = scale;
  const at = (v) => mid + (v - mid) * s;

  // 上箭头（指向右）
  canvas.fill(WHITE, (x, y) => rect(at(0.28), at(0.415), at(0.63), at(0.475))(x, y));
  canvas.fill(WHITE, triangle(at(0.58), at(0.35), at(0.58), at(0.54), at(0.75), at(0.445)));
  // 下箭头（指向左）
  canvas.fill(WHITE, (x, y) => rect(at(0.37), at(0.525), at(0.72), at(0.585))(x, y));
  canvas.fill(WHITE, triangle(at(0.42), at(0.46), at(0.42), at(0.65), at(0.25), at(0.555)));
}

function make({ size, rounded, fullBleed, glyphScale, file }) {
  const canvas = new Canvas(size);
  if (fullBleed) {
    canvas.fill(BLUE, () => true);
  } else {
    canvas.fill(BLUE, roundedRect(rounded, 0));
  }
  drawGlyph(canvas, glyphScale);
  const png = encodePng(canvas.data, size, size);
  fs.writeFileSync(path.join(OUT_DIR, file), png);
  console.log(`  ${file}  ${size}x${size}  ${(png.length / 1024).toFixed(1)} KB`);
}

fs.mkdirSync(OUT_DIR, { recursive: true });
console.log('生成图标：');
make({ size: 192, rounded: 0.22, glyphScale: 1, file: 'icon-192.png' });
make({ size: 512, rounded: 0.22, glyphScale: 1, file: 'icon-512.png' });
// maskable 需要留安全边距（图形缩到 ~72%），且必须满幅无透明
make({ size: 512, fullBleed: true, glyphScale: 0.72, file: 'icon-512-maskable.png' });
// iOS 主屏图标：满幅，系统会自己切圆角
make({ size: 180, fullBleed: true, glyphScale: 1, file: 'apple-touch-icon.png' });
console.log('完成 → public/icons/');
